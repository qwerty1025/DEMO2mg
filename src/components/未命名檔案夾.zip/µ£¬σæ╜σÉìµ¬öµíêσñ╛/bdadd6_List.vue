<template>
    <div class=" flex justify-center  ">
    
        <div class="w-3/12 ml-4  h-screen ">
    
            <div class=" justify-center w-full "  >
                <div class="mx-1">
                    <v-overlay :value="overlay" :opacity="opc" class="h-auto">
                        <div class="grid grid-cols-5 gap-0 pt-10">
                            <div class="col-span-5 pl-5">
    
    
                            </div>
                            <div class="col-span-3 pl-5">
    
                                <span class="text-blue-500 bg-white px-4 p-3 m-3 rounded-full text-3xl font-black" v-if="currentTutorial !== null ">將 {{currentTutorial.sno }}-{{currentTutorial.sno_idx }} 替換至 </span>
                                <span v-show="copyMore == false" class="text-red-500 bg-white px-4 p-3 m-3 rounded-full text-3xl font-black">{{toHere.sno}}-{{toHere.sno_idx}}</span>
                                <!-- 這邊是全部{{ toHere_more }}
                                    <br>
                                    第一批次 {{ toHere_more12 }} 
                                    <hr>
                                    第二批次 {{ toHere_more34 }} -->
                            </div>
    
                            <div class="col-span-2 flex">
    
                                <v-checkbox class="mx-5 py-6" v-model="copyMore" :label="`移動.多靶位`">
                                </v-checkbox>
                                <v-btn color="#D32F2F" @click="clear_chgPos()" class="m-1">
                                    取消
                                </v-btn>
    
                                <v-btn v-show="copyMore == false" color="#1976D2" dark @click="changPos(toHere.key)" class="m-1">
                                    送出
                                </v-btn>
    
    
                                <v-btn v-show="copyMore == true &&  preCC == false" color="#16a34a" dark @click="pre_BeClear()" class="m-1">
                                    清理 .移動靶位
                                </v-btn>
    
                                <v-btn v-show="preCC == true " color="#4f46e5" dark @click="changPos_more()" class="m-1">
                                    修改 .多靶位
                                </v-btn>
    
    
    
                            </div>
    
                            <div class="col-span-5  flex ">
                                <div class="w-1/5 bg-green-600 rounded-xl py-3">
                                    <span class="ml-16" v-show="copyMore == false"> 使用中的靶位 </span>
                                    <span class="ml-16" v-show="copyMore == true"> 步驟(1).先清理靶位 </span>
                                    <v-chip-group column multiple v-model="beClear" class="mx-10 ">
                                        <v-chip active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" v-if="tutorial.ply_statu != '' | tutorial.left_time != ''" :key="index" :value="tutorial" :color="red" filter>
                                            {{ tutorial.sno }}-{{tutorial.sno_idx }}，{{tutorial.left_time }} 離
                                        </v-chip>
                                    </v-chip-group>
                                </div>
    
                                <div class="w-4/5">
    
    
                                    <div v-show="copyMore == false" class="bg-red-400 rounded-xl px-5 py-3">
    
                                        <span class=" ml-16"> 這兒空著呢！ </span>
                                        <v-chip-group column v-model="toHere" class="mx-10">
                                            <v-chip active-class="bg-green-800 text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.ply_statu == '' &&  tutorial.left_time == ''">
                                                {{ tutorial.sno }}-{{tutorial.sno_idx }}，{{tutorial.left_time }} 離
                                            </v-chip>
                                        </v-chip-group>
                                    </div>
    
                                    <div class="bg-yellow-400 rounded-xl px-5 py-3" v-show="copyMore == true">
                                        <span class="ml-16 text-gray-900 "> 步驟(2).選擇 多個更換的靶位，接著按下綠色按鈕。 </span>
                                        <div class="flex w-full">
                                            <div class="w-1/2">
                                                <v-chip-group v-model="toHere_more12" class="" column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 1 | tutorial.sno == 2 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more34" class="" column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 3 | tutorial.sno == 4 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more56" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 5 | tutorial.sno == 6 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more78" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 7 | tutorial.sno == 8 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more910" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 9 | tutorial.sno == 10 && tutorial.left_time == ''  "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more11" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 11 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
                                            </div>
    
                                            <div class="w-1/2">
                                                <v-chip-group v-model="toHere_more1213" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 12 | tutorial.sno == 13 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more1415" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 15 | tutorial.sno == 14 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more1716" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 17 | tutorial.sno == 16 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more1918" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 19 | tutorial.sno == 18 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more2021" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 21 | tutorial.sno == 20 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more2223" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 22 | tutorial.sno == 23 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
    
                                                <v-chip-group v-model="toHere_more2425" class=" " column multiple>
                                                    <v-chip small active-class="bg-blue-800   text-white text-x" v-for="(tutorial, index) in tutorials" :key="index" :value="tutorial" v-if="tutorial.sno == 24 | tutorial.sno == 25 && tutorial.left_time == '' "> {{ tutorial.sno }}-{{ tutorial.sno_idx }}
                                                    </v-chip>
                                                </v-chip-group>
                                            </div>
    
                                        </div>
    
                                    </div>
                                </div>
                            </div>
    
                        </div>
    
                    </v-overlay> 
                </div>
    
                <div class="grid grid-cols-4 gap-1">

                    <div class="col-span-5 text-gray-900 bg-gray-200 rounded-2xl my-1 p-3 text-xs">
                        <span class=""> 目前上線人數： </span>
                        <br> 北:餘 <span class="text-base text-gray-900 font-black">  {{ 30 - cfg_Pos_1 }} </span>  空位, <span class="text-base text-gray-900 font-black">  {{ cfg_Pos_1 }} </span> 位使用中, <span class="text-base text-gray-900 font-black">  {{ cfg_Pos_3 }} </span> 位超時
                        <br> 南:餘 <span class="text-base text-gray-900 font-black">  {{ 30 - cfg_Pos_2 }} </span>  空位, <span class="text-base text-gray-900 font-black">  {{ cfg_Pos_2 }} </span> 位使用中, <span class="text-base text-gray-900 font-black">  {{ cfg_Pos_4 }} </span> 位超時
                    </div> 

                    <div class="col-span-5 grid grid-cols-4 gap-0 bg-gray-200 rounded-l-2xl my-1 px-1">
    
                    <v-checkbox v-model="copyRight_T" class="text-xs col-span-1" :label="`批次設定`"></v-checkbox>
                    <v-text-field clearable solo dense v-model="bch_left_time" 
                    class="text-xs my-2 mx-1 col-span-3" label="請設定離場時間" placeholder="">
                    </v-text-field>
                    <!-- <input class="  bg-white appearance-none border rounded col-span-3 py-1 px-3 
                                    text-gray-700 leading-tight focus:outline-none 
                                    focus:shadow-outline" type="text"  
                                    v-model="bch_left_time" 
                                    placeholder="統一離場時間"> -->
    
                    <!-- <hr class="col-span-5"> -->
    
                    <v-checkbox v-model="copyRight_N" class="text-xs col-span-1" :label="`批次設定`"></v-checkbox>
                    <v-text-field clearable solo dense v-model="bch_tmp_idx" 
                    class="text-xs my-2 mx-1 col-span-3" label="複製牌號/ 備註" placeholder="">
                    </v-text-field>

                    <!-- <input class="  bg-white appearance-none border rounded col-span-3 py-1 px-3 
                                    text-gray-700 leading-tight focus:outline-none 
                                    focus:shadow-outline" type="text"  
                                    v-model="bch_tmp_idx" 
                                    placeholder="複製牌號/ 備註"> -->
    
                    <!-- <hr class="col-span-5"> -->
    
                    <v-checkbox v-model="copyRight_N_auto" 
                                class="text-xs col-span-1" :label="`自動遞增`" 
                                @change="cfg()">
                    </v-checkbox>
    
                    <v-text-field clearable solo dense 
                                    v-model="auto_tmp_idx" class="text-xs my-2 mx-1 col-span-1" 
                                    label="號碼" placeholder="">
                    </v-text-field> 
    
                    <v-text-field clearable solo dense 
                                    v-show="copyRight_N_auto == true " 
                                    v-model="bch_left_time" class="text-xs my-2 mx-1 col-span-2" 
                                    label="離場時間" placeholder="">
                    </v-text-field>
                    </div>

                     <div class="col-span-5 bg-gray-200 rounded-l-2xl py-3 px-1">
                            <div class="flex mt-30">
                                <input class=" bg-white appearance-none border rounded-3xl w-2/3 py-2 px-3 mb-3 
                                        text-gray-700 leading-tight focus:outline-none 
                                        focus:shadow-outline" type="text" 
                                        @change=" " 
                                v-model="BkLst_Now.pre_tmp_idx" placeholder="牌號/ 顧客暱稱">

                                <v-btn   color="#E91E63"
                                        class="w-1/3 my-1 px-1" 
                                        small dark dense rounded
                                        @click="save_BkingNote()"> 
                                        建立預約 </v-btn> 
                            </div> 
                            <div class="flex mt-30">

                                <v-text-field small class="mx-3 w-1/4" label="入場.報到.時間" 
                                            v-model=" BkLst_Now.pre_left_time " @change="" dense>
                                </v-text-field> 

                                <v-text-field small class="mx-3 w-1/4" label="人數" 
                                            v-model=" BkLst_Now.ply_amt " @change="" dense>
                                </v-text-field> 

                                <v-text-field small class="mx-3 w-1/3" label="手機" 
                                            v-model=" BkLst_Now.pre_mb_phone " @change="" dense>
                                </v-text-field>  
                            </div>  
                        </div> 

                    <div class="col-span-5 flex">
                        <div class="w-1/3">
                            <v-checkbox text v-model="dialog" @click="removeST" label="靶位清理"></v-checkbox>  
                            <v-row>
                                <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_0">全場(01 ~ 20)</v-btn>
                                <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_1">北場(01 ~ 11)</v-btn>
                                <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_2">南場(12 ~ 18)</v-btn>
                            </v-row>
                        </div>
                        
                        <div class="w-1/3">
                            
                            <v-checkbox v-model="shouldPut" 
                                        class="text-xs w-full" 
                                        @click="chk_preSt()"
                                        :label="`預備靶位`"></v-checkbox>   
                        </div>
                        <div class="w-1/3">
                            
                            <v-checkbox v-model="copyRight_M"  class="text-xs w-full" :label="`換預約玩`"></v-checkbox> 
                        </div>
                    </div>      
                        <span v-show="shouldPut == true" 
                                 class="col-span-5 text-gray-900 bg-yellow-400 py-2 px-2 font-black text-s"> 
                                 正在安排 {{ BkLists[LstX].pre_left_time }}，{{ BkLists[LstX].pre_tmp_idx}} 的位子 </span>
                     
                    <div class="col-span-5">
                   
                    
                    <v-tabs v-model="tabp" active-class="bg-green-500 text-white" dark fixed-tabs>
                    <v-tab key='p1' href='#p1' v-if="!hide">
                        預約表
                    </v-tab>
    
                    <v-tab key='p3' href='#p3'>
                        已上線
                    </v-tab>
    
                    <v-tab key='p2' href='#p2' v-if="!hide">
                        取消
                    </v-tab>
                </v-tabs>
                <v-tabs-items v-model="tabp">
                    <v-tab-item key='p1' value='p1'>
                        <v-card
                            v-scroll.self="onScrollx"
                            class="bg-green-200 col-span-5 h-screen mt-2 pr-1 overflow-y-auto"
                            max-height="1080"
                        >
                             <!-- LstX : {{ LstX }} -->
                             <!-- {{ BkLists }}  popout  -->
                            <v-expansion-panels v-model="LstX">
                                <v-expansion-panel
                                    v-for="(item,i) in BkLists"
                                    v-show=" item.ply_statu =='預約'"
                                    :key="i"
                                >
                                    <v-expansion-panel-header>

                                        <!-- <span class=" p-1 bg-red-500 rounded-full text-white text-xs font-black"> {{ stCNT_1(item.pre_tmp_idx+';'+item.pre_left_time) }} </span>  -->
                                    <!-- <v-spacer></v-spacer> -->
                                     <div class=" flex-row  ">

                                       
                                        <div class="w-full ">
                                            <v-btn   color="#E91E63" class="" x-small filter dark solo rounded
                                             @click="bch_chg_CHKin( item.pre_tmp_idx,item.pre_left_time,item )"> 全上線</v-btn>   

                                            <span class=" p-1 text-gray-700 text-xs font-black"> 
                                                 {{item.pre_left_time}},{{ item.pre_tmp_idx }}共{{item.ply_amt}}位,排： </span>
                                        </div>

                                        <div class="w-full my-2 ">
                                            <v-chip-group column multiple v-model="item.stCNT" class="mx-1 " label="預排位置">
                                                <v-btn  
                                                    v-for="(tutorial, index) in tutorials"  
                                                    :key="index" close x-small class="mx-1 " color="#0470dc" dark
                                                    @click="close=dlt_preSt(tutorial)"
                                                    v-if="tutorial.memo == item.pre_tmp_idx+';'+item.pre_left_time" >
                                                    {{ tutorial.sno }}-{{tutorial.sno_idx }} 
                                                    <v-icon
                                                        right
                                                        dark
                                                    >
                                                        mdi-close
                                                    </v-icon> 
                                                </v-btn> 
                                            </v-chip-group>
                                        </div>
                                     </div>                 
                                      <template v-slot:actions>
                                            <v-icon color="error">
                                            $expand

                                            </v-icon>
                                        </template>
                                    </v-expansion-panel-header>

                                    <v-expansion-panel-content>
                                    <!-- L quip ex ea commodo consequat. -->
                                    <hr class="my-1">
                                    <div class="flex mt-30">
                                        <input class=" bg-white appearance-none border rounded w-2/3 py-2 px-3 mb-3 
                                                    text-gray-700 leading-tight focus:outline-none 
                                                    focus:shadow-outline" type="text" 
                                                    @change=" " 
                                            v-model="item.pre_tmp_idx" placeholder="牌號/ 顧客暱稱">

                                        <v-btn   color="#E91E63"
                                                class="w-1/3 my-1 px-1" 
                                                small dark dense rounded
                                                @click="updateBkingNote(item)"> 
                                                更新 </v-btn>
                                    </div>       

    
                                    <div class="flex mt-30">

                                        <v-text-field small class="mx-1 w-1/3" label="手機" 
                                                    v-model=" item.pre_mb_phone " @change="" dense>
                                        </v-text-field>

                                        <v-text-field small class="mx-1 w-1/4" label="入場.報到.時間" 
                                                    v-model=" item.pre_left_time " @change="" dense>
                                        </v-text-field> 

                                        <v-text-field small class="mx-1 w-1/4" label="人數" 
                                                    v-model=" item.ply_amt " @change="" dense>
                                        </v-text-field>  
                                    </div>    
                                    
                                    <v-btn   color="#E91E63" class="mx-1" small filter dark solo 
                                             @click="bch_chg_CHKin( item.pre_tmp_idx,item.pre_left_time,item )"> 全上線</v-btn>   

                                    <v-btn   color="#545454" class="mx-1" small filter dark solo 
                                             @click="dlt_preBking(item,'取消預約')">取消預約</v-btn>
                                    </v-expansion-panel-content>
                                </v-expansion-panel>
                            </v-expansion-panels>  
                        </v-card>  
                    </v-tab-item>
                    <v-tab-item key='p2' value='p2'>
                        <v-card
                            v-scroll.self="onScrollx"
                            class="bg-green-200 col-span-5 h-screen mt-2 pr-1 overflow-y-auto"
                            max-height="1080"
                        >
                             <!-- LstX : {{ LstX }} -->
                             <!-- {{ BkLists }}  popout  -->
                            <v-expansion-panels v-model="LstX">
                                <v-expansion-panel
                                    v-for="(item,i) in BkLists"
                                    v-show=" item.ply_statu =='取消預約'"
                                    :key="i"
                                >
                                    <v-expansion-panel-header> 
                                     <div class=" flex-row  ">

                                       
                                        <div class="w-full ">
                                            <span class=" p-1 text-gray-700 text-xs font-black"> 
                                                 {{item.pre_left_time}},{{ item.pre_tmp_idx }}共{{item.ply_amt}}位,排： </span>
                                        </div>

                                        <div class="w-full ">
                                            <v-chip-group column multiple v-model="item.stCNT" class="mx-1 " label="預排位置">
                                                <v-btn  
                                                    v-for="(tutorial, index) in tutorials"  
                                                    :key="index" close x-small class="mx-1 " color="#0470dc" dark
                                                    @click="close=dlt_preSt(tutorial)"
                                                    v-if="tutorial.memo == item.pre_tmp_idx+';'+item.pre_left_time" >
                                                    {{ tutorial.sno }}-{{tutorial.sno_idx }} 
                                                    <v-icon
                                                        right
                                                        dark
                                                    >
                                                        mdi-close
                                                    </v-icon> 
                                                </v-btn> 
                                            </v-chip-group>
                                        </div>
                                     </div>                  <template v-slot:actions>
                                            <v-icon color="error">
                                            $expand

                                            </v-icon>
                                        </template>
                                    </v-expansion-panel-header>

                                    <v-expansion-panel-content>
                                    <!-- L quip ex ea commodo consequat. -->
                                    <hr class="my-1">
                                    <div class="flex mt-30">
                                        <input class=" bg-white appearance-none border rounded w-2/3 py-2 px-3 mb-3 
                                                    text-gray-700 leading-tight focus:outline-none 
                                                    focus:shadow-outline" type="text" 
                                                    @change=" " 
                                            v-model="item.pre_tmp_idx" placeholder="牌號/ 顧客暱稱">

                                        <v-btn   color="#E91E63"
                                                class="w-1/3 my-1 px-1" 
                                                small dark dense rounded
                                                @click="updateBkingNote(item)"> 
                                                更新 </v-btn>
                                    </div>        
    
                                    <div class="flex mt-30">

                                        <v-text-field small class="mx-1 w-1/3" label="手機" 
                                                    v-model=" item.pre_mb_phone " @change="" dense>
                                        </v-text-field>

                                        <v-text-field small class="mx-1 w-1/4" label="入場.報到.時間" 
                                                    v-model=" item.pre_left_time " @change="" dense>
                                        </v-text-field> 

                                        <v-text-field small class="mx-1 w-1/4" label="人數" 
                                                    v-model=" item.ply_amt " @change="" dense>
                                        </v-text-field>  
                                    </div>    
                                    
                                    <v-btn   color="#E91E63" class="mx-1" small filter dark solo 
                                             @click="bch_chg_CHKin( item.pre_tmp_idx,item.pre_left_time,item )"> 全數上線</v-btn>   

                                    <v-btn   color="#545454" class="mx-1" small filter dark solo 
                                             @click="dlt_preBking(item,'刪除預約')">刪除預約</v-btn>
                                    </v-expansion-panel-content>
                                </v-expansion-panel>
                            </v-expansion-panels>  
                        </v-card>  
                    </v-tab-item>
                    <v-tab-item key='p3' value='p3'>
                        <v-card
                            v-scroll.self="onScrollx"
                            class="bg-green-200 col-span-5 h-screen mt-2 pr-1 overflow-y-auto"
                            max-height="1080"
                        >  
                            <v-expansion-panels v-model="LstX">
                                <v-expansion-panel
                                    v-for="(item,i) in BkLists"
                                    v-show=" item.ply_statu =='已安排上線'"
                                    :key="i"
                                >
                                    <v-expansion-panel-header> 
                                     <div class=" flex-row  "> 
                                        <div class="w-full ">
                                            <span class=" p-1 text-gray-700 text-xs font-black"> 
                                                 {{item.pre_left_time}}，{{ item.pre_tmp_idx }}，共{{item.ply_amt}} 位，安排： </span>
                                        </div>

                                        <div class="w-full ">
                                            <v-chip-group column multiple v-model="item.stCNT" class="mx-1 " label="預排位置">
                                                <v-btn  
                                                    v-for="(tutorial, index) in tutorials"  
                                                    :key="index" close x-small class="mx-1 " color="#0470dc" dark
                                                    @click="close=dlt_preSt(tutorial)"
                                                    v-if="tutorial.memo == item.pre_tmp_idx+';'+item.pre_left_time" >
                                                    {{ tutorial.sno }}-{{tutorial.sno_idx }} 
                                                    <v-icon right dark >
                                                        mdi-close
                                                    </v-icon> 
                                                </v-btn> 
                                            </v-chip-group>
                                        </div>
                                     </div>                  <template v-slot:actions>
                                            <v-icon color="error">
                                            $expand 
                                            </v-icon>
                                        </template>
                                    </v-expansion-panel-header>

                                    <v-expansion-panel-content>                                      <hr class="my-1">
                                    <div class="flex mt-30">
                                        <input class=" bg-white appearance-none border rounded w-2/3 py-2 px-3 mb-3 
                                                    text-gray-700 leading-tight focus:outline-none 
                                                    focus:shadow-outline" type="text" 
                                                    @change=" " 
                                            v-model="item.pre_tmp_idx" placeholder="牌號/ 顧客暱稱">

                                        <v-btn   color="#E91E63"
                                                class="w-1/3 my-1 px-1" 
                                                small dark dense rounded
                                                @click="updateBkingNote(item)"> 
                                                更新 </v-btn>
                                    </div>       

    
                                    <div class="flex mt-30">

                                        <v-text-field small class="mx-1 w-1/3" label="手機" 
                                                    v-model=" item.pre_mb_phone " @change="" dense>
                                        </v-text-field>

                                        <v-text-field small class="mx-1 w-1/4" label="入場.報到.時間" 
                                                    v-model=" item.pre_left_time " @change="" dense>
                                        </v-text-field> 

                                        <v-text-field small class="mx-1 w-1/4" label="人數" 
                                                    v-model=" item.ply_amt " @change="" dense>
                                        </v-text-field>  
                                    </div>    
                                    
                                    <!-- <v-btn   color="#E91E63" class="mx-1" small filter dark solo 
                                             @click="bch_chg_CHKin( item.pre_tmp_idx,item.pre_left_time,item )"> 全數上線</v-btn>  -->  

                                    <v-btn   color="#545454" class="mx-1" small filter dark solo 
                                             @click="dlt_preBking(item,'隱藏顯示')">隱藏顯示</v-btn>
                                    </v-expansion-panel-content>
                                </v-expansion-panel>
                            </v-expansion-panels>  
                        </v-card>  
                    </v-tab-item>
                </v-tabs-items>

                </div> 
                </div>
            </div>
        </div>
    
        <div class="w-11/12  ">
            <v-card v-scroll.self="onScroll" class="overflow-y-auto" max-height="1080">
    
    
                <v-tabs v-model="tab" active-class="bg-gray-900 text-white" fixed-tabs>
                    <v-tab key='k1' href='#k1' v-if="!hide">
                        中央 _北場
                    </v-tab>
    
                    <v-tab key='k2' href='#k2'>
                        中央 _南場
                    </v-tab>
    
                    <v-tab key='k4' href='#k4' v-if="!hide">
                        北北東 _場
                    </v-tab>
                </v-tabs>
                <v-tabs-items v-model="tab">
    
                    <v-tab-item key='k1' value='k1'>
                        <div>
                            <v-list-item-group color="primary" class="grid grid-cols-6 gap-0  ">
                                <v-list-item v-for="(tutorial, index) in tutorials" :key="index" v-if="tutorial.pos =='北'" @click="setActiveTutorial(tutorial, index)" class="p-1">
                                    <v-list-item-content class=" col-span-1 pt-1.5 pb-0.5 my-1 flex flex-row-reverse text-xs border-2 rounded-sm " :class="{ [`bg-${color[parseInt(tutorial.sno)]}-100 border-${color[parseInt(tutorial.sno)]}-300`]: 1 }" @click="setActiveTutorial(tutorial, index)">
     
                                        <div class="col-span-1 flex pl-1">
                                            <v-chip class=" w-auto " :color="ChkTime2getColor(tutorial.left_time)" @click="chgPos(tutorial)">
                                                <a class=" font-bold text-white">{{ tutorial.sno }}-{{ tutorial.sno_idx }} </a>
                                            </v-chip>
    
                                            <v-text-field small class="w-1/3 mx-3" label="離場時間" v-model=" tutorial.left_time " @change="upldleft_time(tutorial)" dense></v-text-field>
    
                                            <v-btn class="" x-small v-show="dialog" @click="upld_Claer(tutorial)">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                    </svg>
                                            </v-btn> 
                                            <v-btn class="" x-small v-show="ChkTime2getColor(tutorial.left_time) == '#E91E63' && dialog ==false " @click="upld_Claer(tutorial)">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                    </svg>
                                            </v-btn> 
                                        </div>
                                        <div class="col-span-1 flex"> 
                                             
                                            <input class=" bg-white appearance-none border rounded w-full py-2 px-3 
                                                                text-gray-700 leading-tight focus:outline-none 
                                                                focus:shadow-outline" type="text" @change="upldtmp_idx(tutorial)" v-model="tutorial.tmp_idx" placeholder="牌號/ 顧客暱稱">
    
                                            <v-btn v-show="tutorial.ply_statu == '我要續時'" class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續時.繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 0.5' " class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續0.5繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 1.0' " class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續1.0繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '問過不續' " class="mx-1" color="#475569" small filter dark solo value="問過不續 "> 問過不續 </v-btn>
                                        
                                        </div> 
                                        <div class="flex"> 
                                             
                                            <v-chip 
                                            v-show="copyRight_M == false  && tutorial.memo != ''"  small dark
                                            class="flex-auto bg-red-500 my-2 p-2 font-black text-red-100 text-s" 
                                            color="#E91E63"
                                            >  預
                                            </v-chip>  
                                            
                                            <v-chip-group class="pl-2" v-model="tutorial.ply_statu" @change="upldStatu(tutorial)" column>
                                            

                                            <v-chip class="px-2" v-show="tutorial.ply_statu != '續.已繳'" filter small outlined value="首次"> 首 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="免講習"> 免 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="上課"> 課 </v-chip>
                                            <v-chip class="px-2" v-show="tutorial.ply_statu == '續.已繳'" filter small outlined value="續.已繳"> 續</v-chip>
                                        </v-chip-group>  
                                        </div> 
                                        <div v-show="copyRight_M == true " class="col-span-1 flex">
                                            <v-text-field small dense clearable class="w-2/3 mx-3" label="下時段安排" 
                                                         @change="upldplayGp(tutorial)" 
                                                         v-model="tutorial.memo">
                                            </v-text-field>
                                            
                                            <v-btn  color="#E91E63" class="w-auto my-2 mr-1" x-small dark solo 
                                                    v-show="copyRight_M  == true && shouldPut == false"  
                                                    value="我要續時" @click="chg_CHKin(tutorial)"> 換人 </v-btn>
                                        </div>
    
                                    </v-list-item-content>
                                </v-list-item>
    
                            </v-list-item-group>
                        </div>
                    </v-tab-item>
    
                    <v-tab-item key='k2' value='k2'>
                        <div>
                            <v-list-item-group color="primary" class="grid grid-cols-6 gap-0  ">
                                <v-list-item v-for="(tutorial, index) in tutorials" :key="index" v-if="tutorial.pos =='南'" @click="setActiveTutorial(tutorial, index)" class="p-1">
                                    <v-list-item-content class=" col-span-1 pt-1.5 pb-0.5 my-1 flex flex-row-reverse text-xs border-2 rounded-sm " :class="{ [`bg-${color2[parseInt(tutorial.sno)]}-100 border-${color2[parseInt(tutorial.sno)]}-300`]: 1 }" @click="setActiveTutorial(tutorial, index)">
    
                                        <div class="col-span-1 flex pl-1">
                                            <v-chip class=" w-auto " :color="ChkTime2getColor(tutorial.left_time)" @click="chgPos(tutorial)">
                                                <a class=" font-bold text-white">{{ tutorial.sno }}-{{ tutorial.sno_idx }} </a>
                                            </v-chip>
    
                                            <v-text-field small class="w-1/3 mx-3" label="離場時間" v-model=" tutorial.left_time " @change="upldleft_time(tutorial)" dense></v-text-field>
    
                                            <v-btn class="" x-small v-show="dialog" @click="upld_Claer(tutorial)">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                    </svg>
                                            </v-btn> 
                                            <v-btn class="" x-small v-show="ChkTime2getColor(tutorial.left_time) == '#E91E63' && dialog ==false " @click="upld_Claer(tutorial)">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                    </svg>
                                            </v-btn> 
                                        </div>
                                        <div class="col-span-1 flex"> 
                                             
                                            <input class=" bg-white appearance-none border rounded w-full py-2 px-3 
                                                                text-gray-700 leading-tight focus:outline-none 
                                                                focus:shadow-outline" type="text" @change="upldtmp_idx(tutorial)" v-model="tutorial.tmp_idx" placeholder="牌號/ 顧客暱稱">
    
                                            <v-btn v-show="tutorial.ply_statu == '我要續時'" class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續時.繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 0.5' " class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續0.5繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 1.0' " class="mx-1" color="#4f46e5" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續1.0繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '問過不續' " class="mx-1" color="#475569" small filter dark solo value="問過不續 "> 問過不續 </v-btn>
                                        
                                        </div> 
                                        <div class="flex"> 
                                             
                                            <v-chip 
                                            v-show="copyRight_M == false  && tutorial.memo != ''"  small dark
                                            class="flex-auto bg-red-500 my-2 p-2 font-black text-red-100 text-s" 
                                            color="#E91E63"
                                            > 預 
                                            </v-chip>  
                                            
                                            <v-chip-group class="pl-2" v-model="tutorial.ply_statu" @change="upldStatu(tutorial)" column>
                                            

                                            <v-chip class="px-2" v-show="tutorial.ply_statu != '續.已繳'" filter small outlined value="首次"> 首 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="免講習"> 免 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="上課"> 課 </v-chip>
                                            <v-chip class="px-2" v-show="tutorial.ply_statu == '續.已繳'" filter small outlined value="續.已繳"> 續</v-chip>
                                        </v-chip-group>  
                                        </div> 
                                        <div v-show="copyRight_M == true " class="col-span-1 flex">
                                            <v-text-field small dense clearable class="w-2/3 mx-3" label="下時段安排" 
                                                         @change="upldplayGp(tutorial)" 
                                                         v-model="tutorial.memo">
                                            </v-text-field>
                                            
                                            <v-btn  color="#E91E63" class="w-auto my-2 mr-1" x-small dark solo 
                                                    value="我要續時" @click="chg_CHKin(tutorial)"> 換人 </v-btn>
                                        </div>
 
    
                                    </v-list-item-content>
                                </v-list-item>
    
                            </v-list-item-group>
                            
                        </div>
                    </v-tab-item>
    
                    <v-tab-item key='k3' value='k3'>
                        <div>
                            <!-- {{ tutorial }} --> 
                            <v-list-item-group color="primary" class="grid grid-cols-6 gap-0  ">
                                <v-list-item v-for="(tutorial, index) in tutorials" :key="index" v-if="tutorial.pos =='南'" @click="setActiveTutorial(tutorial, index)" class="p-1">
                                    <v-list-item-content class=" col-span-1 pt-1.5 pb-0.5 my-1 flex flex-row-reverse text-xs border-2 rounded-sm " :class="{ [`bg-${color2[parseInt(tutorial.sno)]}-100 border-${color2[parseInt(tutorial.sno)]}-300`]: 2 }" @click="setActiveTutorial(tutorial, index)">
    
                                        <!-- order-last -->
                                        <div class="col-span-1 flex pl-1">
                                            <v-chip class=" w-auto " :color="ChkTime2getColor(tutorial.left_time)" @click="chgPos(tutorial)">
                                                <a class=" font-bold text-white">{{ tutorial.sno }}-{{ tutorial.sno_idx }} </a>
                                            </v-chip>
    
                                            <v-text-field small class="w-1/3 mx-3" label="離場時間" v-model=" tutorial.left_time " @change="upldleft_time(tutorial)" dense></v-text-field>
    
                                            <v-btn class="" x-small v-show="dialog" @click="upld_Claer(tutorial)">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                            </svg>
                                            </v-btn>
                                        </div>
                                        <div class="col-span-1 flex">
    
                                            <!-- <v-text-field solo class="col-span-1 mx-10" label="牌號" v-model=" tutorial.tmp_idx " @change="upldtmp_idx(tutorial)" dense></v-text-field> -->
    
                                            <input class=" bg-white appearance-none border rounded w-full py-2 px-3 
                                                                      text-gray-700 leading-tight focus:outline-none 
                                                                      focus:shadow-outline" type="text" @change="upldtmp_idx(tutorial)" v-model="tutorial.tmp_idx" placeholder="牌號/ 顧客暱稱">
    
                                            <v-btn v-show="tutorial.ply_statu == '我要續時'" color="#4f46e5" class="mx-1" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續時.繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 0.5' " color="#4f46e5" class="mx-1" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續0.5繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '續 1.0' " color="#4f46e5" class="mx-1" small filter dark solo value="我要續時" @click="extendPayChk(tutorial)"> 續1.0繳費 </v-btn>
                                            <v-btn v-show="tutorial.ply_statu == '問過不續' " class="mx-1" color="#475569" small filter dark solo value="問過不續  "> 問過不續 </v-btn>
                                        </div>
                                        <v-text-field class="col-span-1 mr-3" v-show="use_BKingGp" label="客人備註" v-model=" tutorial.memo " @change="upldplayGp(tutorial)" dense></v-text-field>
    
    
                                        <v-chip-group v-model="tutorial.ply_statu" @change="upldStatu(tutorial)" column class="">
                                            <v-chip class="px-2" filter small outlined value="首次"> 首 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="免講習"> 免 </v-chip>
                                            <v-chip class="px-2" filter small outlined value="上課"> 課 </v-chip>
                                            <v-chip class="px-2" v-show="tutorial.ply_statu == '續.已繳'" filter small outlined value="續.已繳"> 續 </v-chip>
                                        </v-chip-group>
    
                                    </v-list-item-content>
                                </v-list-item>
    
                            </v-list-item-group>
    
                        </div>
                    </v-tab-item>
                </v-tabs-items>
            </v-card>
        </div>
    
    
    
    </div>
</template>
 

<script>
import TutorialDetails from "./bkadd5_Mdf";
import TutorialDataService from "../services/SeatPrepareService";



import BkingNoteDataService from "../services/BkingNoteDataService";

import SeatDataService from "../services/SeatPrepareService";

import HistoryDataService from "../services/HistoryDataService";
import dayjs from 'dayjs';


import PmtDataService from "../services/PmtService";
import Vue from 'vue'
import JsonCSV from 'vue-json-csv'
Vue.component('downloadCsv', JsonCSV)

export default {
    name: "tutorials-list",
    components: { TutorialDetails },


    data() {
        return {
            // - - - - - 
            currentTime: Date.now(),
            cT: "",
            cuT: "",
            plySTATU: "",
            amenities: [],
            exists_Now: [0, 0, 0, 0, 0, 0],
            // - - - - - 
            switch1: true,
            switch2: false,
            opc: 0.8,
            color: ['red', 'red', 'red', 'yellow', 'yellow', 'green', 'green', 'gray', 'gray', 'blue', 'blue', 'red', 'red', 'blue', 'blue',
                'green', 'green', 'red', 'red', 'green', 'green', 'red', 'red', 'yellow', 'yellow', 'blue', 'blue', 'green', 'green',
                'red', 'red', 'yellow', 'yellow', 'green', 'green', 'red', 'red', 'yellow', 'yellow'
            ],

            color2: ['red', 'red', 'red', 'yellow', 'yellow', 'green', 'green', 'gray', 'gray', 'blue', 'blue', 'yellow', 'yellow', 'yellow', 'blue', 'blue',
                'green', 'green', 'red', 'red', 'gray', 'gray', 'red', 'red', 'yellow', 'yellow', 'blue', 'blue', 'green', 'green',
                'red', 'red', 'yellow', 'yellow', 'green', 'green', 'red', 'red', 'yellow', 'yellow'
            ],


            ex11: ['red'],
            ex: false,
            // - - - - - - - - - - - - - - -
            ExTndpanel:[],
            sheet: false,
            pre_idx:"",
            LstX:[0],
            shouldPut:false,

            BkLst_Now:{
                pre_tmp_idx: '',
                pre_mb_phone:  '',
                pre_left_time: '',

                ply_amt:'', 
                ply_statu: '預約',
                pre_Seat:['0'],  
            },
           
           BkLists_Draft: [    
                        {
                            pre_tmp_idx: '劉水席',
                            pre_mb_phone: '0923444555',
                            pre_left_time:'13:00',
                            ply_amt:1, 
                            pre_Seat:[], 
                        },
                        {
                            pre_tmp_idx: '吳小媚(2大1小)',
                            pre_mb_phone: '0923444555',
                            pre_left_time:'13:00',

                            ply_amt:3, 
                            ply_statu:'預約',
                            pre_Seat:[],
                        },
                        {
                            pre_tmp_idx: '廖大砲',
                            pre_mb_phone: '0923444345',
                            pre_left_time:'12:00',
                            ply_amt:2, 
                            ply_statu:'預約',
                            pre_Seat:[],
                        },
                        {
                            pre_tmp_idx: '董員外(全明星藝人)',
                            pre_mb_phone: '0929944555',
                            pre_left_time:'14:00',
                            ply_amt:4, 
                            ply_statu:'預約',
                            pre_Seat:[],
                        },
                        {
                            pre_tmp_idx: '言承旭',
                            pre_mb_phone: '09287644555',
                            pre_left_time:'16:00',
                            ply_amt:6, 
                            ply_statu:'預約',
                            pre_Seat:[],
                        }, 
                    ],
            
            locations: ['Australia', 'Barbados', 'Chile', 'Denmark', 'Ecuador', 'France'],
            
            // - - - - - - - - - - - - - - -

            dialog: false,
            tab: "",
            tabp: "",
            ckbx: "",
            copyRight_N: false,
            copyRight_T: false,
            copyRight_M: false,
            copyRight_N_auto: false,

            // - - - - - - - - - - - - - - - 
            dev_TooL_show: false,
            Dev_Tool_0: false,
            Dev_Tool_1: false,
            Dev_Tool_2: false,
            Dev_Tool_3: false,

            bch_left_time: "",
            bch_tmp_idx: "",
            bch_memo: "",
            auto_tmp_idx: "",

            show: false,
            tutorials: [],
            currentTutorial: null,
            currentIndex: -1,

            // - - - -  - - - -  - - - -  - - - -
            use_BKingGp: false,

            // ply_statu_List:['首次','免講習','保留席','續.未繳費','續0.5','續1.0'],
            // - - - -  - - - -  - - - -  - - - -  
            PmtLists: [],

            p: ['key', 'name', 'phone', 'ply_amt', 'plyd'],

            labels: {
                key: '流水編號',
                phone: '手機',

                build_date: '日期',
                ply_amt: '收入金額（＋）',
                mb_id: '會員編號',
                mb_name: '客戶',
                pd_ID: '商品編號',
                pd_name: '產品名稱',

                payCash: '現金',
                payLinPay: 'Linepay',
                payCTCard: '刷卡機',
                payNetBank: '網路(線上)',
                payGovTik: '動滋卷',

                memo: '備註',
                bls_CNT: '差額',
                bls_CNT_reson: '差額原因',

                aCNT_sC: '小分類',
                pcs_price: '單價',
                aCNT_name: '會計科目名稱',
                aCNT_c_ID: '會計科目代號',
                aCNT_c_name: '科目名稱',

                bld_name: '建立者',
            },
            // fields: [ 'name','ply_amt','key','phone','plyd'],
            fields: ['name', 'phone', 'ply_amt', 'key', 'build_date', 'payCash', 'payNetBank', 'payCTCard', 'payGovTik', 'payLinPay', 'memo', 'bls_CNT', 'bls_CNT_reson', 'aCNT_sC', 'pcs_price', 'aCNT_name', 'aCNT_c_ID', 'aCNT_c_name'],
            // 修改_簡化版本  
            // 日期','原因','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','備註','差額','差額原因','付款方式','小分類','單價','會計科目名稱','會計科目代號','科目名稱','建立者','修改時間', 
            // 原版本
            // 日期','原因','日期班別','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','運動卷','熊好卷','迪卡儂卷','台灣pay','發票號碼','備註','差額','差額原因','付款方式','小分類','單價','收入登錄','會計科目名稱','會計科目代號','科目名稱','學員報名課程代號','建立者','修改時間','5倍卷'
            // - - - -  - - - -  - - - -  - - - - 
            // - - - -  - - - -  - - - -  - - - - 
            fileName: 'UUU',
            absolute: true,
            overlay: false,
            overlay2: false,
            copyMore: false,
            preCC: false,
            toHere: "",
            toHere_more: [],
            beClear: [], 

            toHere_mor_tmp_12: [],
            toHere_mor_tmp_34: [],
            toHere_mor_tmp_56: [],
            toHere_mor_tmp_78: [],
            toHere_mor_tmp_910: [],
            toHere_mor_tmp_11: [],
            toHere_mor_tmp_1213: [],
            toHere_mor_tmp_1415: [],
            toHere_mor_tmp_1617: [],
            toHere_mor_tmp_1819: [],
            toHere_mor_tmp_2021: [],
            toHere_mor_tmp_2223: [],
            toHere_mor_tmp_2425: [], 

            start_copy: 0,

        };
    },
    computed: {
        toHere_more: function() {
            return this.toHere_more.filter(c => c.sentTime.indexOf(this.searchs) !== -1)
        }, 

        cfg_Pos_1: function() {
            return this.tutorials.filter(c => c.left_time != '' && c.pos == '北').length
        },

        cfg_Pos_2: function() {
            return this.tutorials.filter(c => c.left_time != '' && c.pos == '南').length
        },

        cfg_Pos_3: function() {
            return this.tutorials.filter(c => c.left_time != '' && c.pos == '北' && this.ChkTime2getColor(c.left_time) == '#E91E63').length
        },

        cfg_Pos_4: function() {
            return this.tutorials.filter(c => c.left_time != '' && c.pos == '南' && this.ChkTime2getColor(c.left_time) == '#E91E63').length
        },

        stCNT_1: function(e) {
            return this.tutorials.filter(c => c.memo == e ).length
        },

        // bkList_rvs: function() {
        //     return this.BkLists.reverse()
        // },
 
    },
    methods: {
        clear_chgPos() {
            this.toHere = "";
            this.toHere_more = [];

            this.toHere_more12 = [];
            this.toHere_more34 = [];
            this.toHere_more56 = [];
            this.toHere_more78 = [];


            this.overlay = false;
            this.copyMore = false;


        },
        chgPos(e) {
            this.overlay = !this.overlay

            // alert(e.key);
        },

        changPos(key) {
            const data = {
                tmp_idx: this.currentTutorial.tmp_idx,
                left_time: this.currentTutorial.left_time,
                // memo: this.currentTutorial.memo,
                ply_statu: this.currentTutorial.ply_statu,
            };
            const OLD = {
                tmp_idx: "",
                left_time: "",
                // memo:"",
                ply_statu: "",
            };

            TutorialDataService.update(key, data)
                .then(() => {})
                .catch((e) => {
                    console.log(e);
                });

            TutorialDataService.update(this.currentTutorial.key, OLD)
                .then(() => {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: '修改完畢!',
                        text: '靶位已進行 調整',
                        showConfirmButton: false,
                        timer: 1200
                    })

                })
                .catch((e) => {
                    console.log(e);
                });
            this.upld_History_mdf(this.currentTutorial);
            this.overlay = false;
        },
        changPos_mdf(ary) {
            for (let i = 0; i <= ary.length - 1; i++) {
                this.changPos(ary[i].key);
            }
            for (let i = 0; i <= this.toHere_more34.length - 1; i++) {
                this.changPos(this.toHere_more34[i].key);
            }
            for (let i = 0; i <= this.toHere_more56.length - 1; i++) {
                this.changPos(this.toHere_more56[i].key);
            }


            this.overlay = false;
            this.clear_chgPos();
        },
        pre_BeClear() {
            //  this.changPos_more();
            this.preCC = true;

            for (let i = 0; i <= this.beClear.length; i++) { this.changPos_BeClear(this.beClear[i].key) }


        },
        chk_preSt()
        {
            if( this.shouldPut == true)
            {
                this.copyRight_M = true;
            }
            else
            {
                this.copyRight_M = false;
            }
        },

        

        changPos_BeClear(h) {

            const data = {
                tmp_idx: "",
                left_time: "",
                // memo:"",
                ply_statu: "",
            };

            TutorialDataService.update(h, data)
                .then(() => {})
                .catch((e) => {
                    console.log(e);
                });

        },

        changPos_more() {

            this.preCC = false;

            if (this.toHere_more12.length != 0) { for (let i = 0; i <= this.toHere_more12.length - 1; i++) { this.changPos(this.toHere_more12[i].key); } }
            if (this.toHere_more34.length != 0) { for (let i = 0; i <= this.toHere_more34.length - 1; i++) { this.changPos(this.toHere_more34[i].key); } }
            if (this.toHere_more56.length != 0) { for (let i = 0; i <= this.toHere_more56.length - 1; i++) { this.changPos(this.toHere_more56[i].key); } }
            if (this.toHere_more78.length != 0) { for (let i = 0; i <= this.toHere_more78.length - 1; i++) { this.changPos(this.toHere_more78[i].key); } }
            if (this.toHere_more910.length != 0) { for (let i = 0; i <= this.toHere_more910.length - 1; i++) { this.changPos(this.toHere_more910[i].key); } }

            if (this.toHere_more11.length != 0) { for (let i = 0; i <= this.toHere_more11.length - 1; i++) { this.changPos(this.toHere_more11[i].key); } }
            if (this.toHere_more1213.length != 0) { for (let i = 0; i <= this.toHere_more1213.length - 1; i++) { this.changPos(this.toHere_more1213[i].key); } }
            if (this.toHere_more1415.length != 0) { for (let i = 0; i <= this.toHere_more1415.length - 1; i++) { this.changPos(this.toHere_more1415[i].key); } }
            if (this.toHere_more1617.length != 0) { for (let i = 0; i <= this.toHere_more1617.length - 1; i++) { this.changPos(this.toHere_more1617[i].key); } }

            if (this.toHere_more1819.length != 0) { for (let i = 0; i <= this.toHere_more1819.length - 1; i++) { this.changPos(this.toHere_more1819[i].key); } }
            if (this.toHere_more2021.length != 0) { for (let i = 0; i <= this.toHere_more2021.length - 1; i++) { this.changPos(this.toHere_more2021[i].key); } }
            if (this.toHere_more2223.length != 0) { for (let i = 0; i <= this.toHere_more2223.length - 1; i++) { this.changPos(this.toHere_more2223[i].key); } }
            if (this.toHere_more2425.length != 0) { for (let i = 0; i <= this.toHere_more2425.length - 1; i++) { this.changPos(this.toHere_more2425[i].key); } }

            this.overlay = false;
            // this.pre_BeClear();

            // for(let i = 0; i <= this.beClear.length; i++) { this.changPos_BeClear(this.beClear[i].key)  }



            this.clear_chgPos();

        },

        removeST() {
            this.bch_memo = "";
            this.bch_left_time = "";
            this.copyRight_M = false;
            this.copyRight_T = false;
        },

        left_Mdf(detal, e) {
            var strAry = e.left_time.split(":");

            if (detal == 1) {

                if (detal == 1) {
                    if (parseInt(strAry[1]) == 30) {
                        e.left_time = parseInt(strAry[0]) + 1 + ":00";
                    } else if (parseInt(strAry[1]) >= 30) {
                        e.left_time =
                            parseInt(strAry[0]) + 1 + ":" + (parseInt(strAry[1]) - 30);
                    } else if (parseInt(strAry[1]) < 30) {
                        e.left_time =
                            strAry[0] + ":" + (parseInt(strAry[1]) + 30);
                    }
                }

                const data = {
                    left_time: e.left_time,
                    ply_statu: '續.已繳',
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });

                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: '修改完畢!',
                    text: '請記得.確認收費',
                    showConfirmButton: false,
                    timer: 1200
                })

            } else if (detal == 2) {
                if (detal == 2) {
                    e.left_time =
                        parseInt(strAry[0]) + 1 + ":" + strAry[1];
                }

                const data = {
                    left_time: e.left_time,
                    ply_statu: '續.已繳',
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });

                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: '修改完畢!',
                    text: '請記得.確認收費',
                    showConfirmButton: false,
                    timer: 1200
                })
            }
        },
        dlt_preSt(e){
            // Swal.fire({
            //             position: 'top-end',
            //             icon: 'errors',
            //             title: '刪除成功',
            //             text: '請 在進行 確認一下喲～',
            //             showConfirmButton: false,
            //         })
            const data = {
                
                memo: "", 
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'error',
                        title: '解除.預排位置',
                        // text: '請 在進行 確認一下喲～',
                        showConfirmButton: false,
                        timer: 1200
                    })
                })
                .catch((e) => {
                    console.log(e);
                });
        }, 
        updateTutorial(e) {
            const data = {
                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                memo: e.memo,
                ply_statu: e.ply_statu,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        upld_ByCHKin(e) {
            const data = {
                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                memo: e.memo,
                ply_statu: '首次',
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        upldtmp_idx(e) {
            const data = {
                tmp_idx: e.tmp_idx,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
            this.upld_History(e);
        },

        upldleft_time(e) {
            const data = {
                left_time: e.left_time,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
            this.upld_History(e);
        },

        upldplayGp(e) {
            const data = {
                // memo: e.memo,
                memo:this.BkLists[this.LstX].pre_tmp_idx+';'+this.BkLists[this.LstX].pre_left_time
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    //  Swal.fire({
                    //         position: 'top-end',
                    //         icon: 'success',
                    //         title: '下時段.新增.成功!', 
                    //         showConfirmButton: false, 
                    //         timer: 800
                    // })

                })
                .catch((e) => {
                    console.log(e);
                }); 
            // this.upld_pre_Seatthis(this.BkLists[this.LstX].key) ;   

        },
        upldStatu(e) {

            if (e.ply_statu == "" | e.ply_statu == null | e.ply_statu == '') {
                const dat = {
                    ply_statu: "",
                };

                TutorialDataService.update(e.key, dat)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });


            } else {
                const data = {
                    ply_statu: e.ply_statu,
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });
            }


            this.upld_History(e);

        },

        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

        upld_History(e) {


            // if( e.tmp_idx !='' && e.left_time != '' && e.ply_statu !='' )
            // {
            const data = {
                // 系統.設定資料
                pos: e.pos,
                sno: e.sno,
                sno_idx: e.sno_idx,
                // 主要變動資料
                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                ply_statu: e.ply_statu,
                // memo:e.memo,   
                cratTime: this.dayjs(Date.now()).toISOString(),
            };

            HistoryDataService.create(data)
                .then(() => {


                    //      Swal.fire({
                    //         position: 'top-end',
                    //         icon: 'warning',
                    //         title: '資料新增成功',
                    //         text: e.left_time+ '請 在進行 確認一下喲～',
                    //         showConfirmButton: false,

                    // })
                })
                .catch((e) => {
                    console.log(e);
                }); 
        },
        upld_History_mdf(e) { 
            const data = {
                // 系統.設定資料
                pos: e.pos,
                sno: e.sno,
                sno_idx: e.sno_idx,
                // 主要變動資料
                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                ply_statu: '換靶位',
                // memo:e.memo,   
                cratTime: this.dayjs(Date.now()).toISOString(),
            };  
            HistoryDataService.create(data)
                .then(() => {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'warning',
                        title: '資料新增成功',
                        text: '請 在進行 確認一下喲～',
                        showConfirmButton: false,
                    })
                })
                .catch((e) => {
                    console.log(e);
                }); 
        },

        upld_Claer(e) {
            const data = {
                memo: "",
                left_time: "",
                tmp_idx: "",
                ply_statu: "",
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        save_BkingNote() {  
            const data = {
                // 系統.設定資料
                pre_tmp_idx: this.BkLst_Now.pre_tmp_idx,
                pre_mb_phone:this.BkLst_Now.pre_mb_phone,
                pre_left_time: this.BkLst_Now.pre_left_time,

                ply_amt: this.BkLst_Now.ply_amt, 
                ply_statu: this.BkLst_Now.ply_statu, 
                pre_Seat:[],

                cratTime: this.dayjs(Date.now()).toISOString(),
            };

            BkingNoteDataService.create(data)
                .then(() => { 

                         Swal.fire({
                            position: 'top-end',
                            icon: 'warning',
                            title: '資料新增成功',
                            text: '已成功 建立預訂 ～',
                            showConfirmButton: false, 
                    })
                })
                .catch((e) => {
                    console.log(e);
                }); 
        },
        upld_pre_Seat(e){
            const data = {
                // 系統.設定資料
                pre_Seat: e.pre_Seat, 
            };

            BkingNoteDataService.update(e.key, data)
                .then(() => { 

                         Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: '位子預定.成功!', 
                            showConfirmButton: false, 
                            timer: 800
                    })
                })
                .catch((e) => {
                    console.log(e);
                }); 

        }, 
        updateBkingNote(e) {  
            const data = {
                // 系統.設定資料
                pre_tmp_idx: e.pre_tmp_idx,
                pre_mb_phone:e.pre_mb_phone,
                pre_left_time: e.pre_left_time, 
                ply_amt: e.ply_amt,  
            };

            BkingNoteDataService.update(e.key, data)
                .then(() => { 

                         Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: '更新資料，上傳成功!', 
                            showConfirmButton: false, 
                            timer: 1200
                    })
                })
                .catch((e) => {
                    console.log(e);
                }); 
        },
 

        dlt_preBking(e,str){ 
            const data = {
                // 系統.設定資料
                ply_statu:str,  
            };

            BkingNoteDataService.update(e.key, data)
                .then(() => { 

                         Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: '成功執行!', 
                            showConfirmButton: false, 
                            timer: 1200
                    })
                })
                .catch((e) => {
                    console.log(e);
                });  
        },

        extendPayChk(e) {
            Swal.fire({
                title: '續時 繳費確認 ',
                text: "教練已詢問，請櫃檯協助收費",
                icon: 'question',
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: '續  0.5 小時',
                denyButtonText: `續 1 小時`,
                cancelButtonText: '取消 !'
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {

                    this.left_Mdf(1, e)
                    // Swal.fire('Saved!', '', 'success')
                } else if (result.isDenied) {

                    this.left_Mdf(2, e)
                    // Swal.fire('Changes are not saved', '', 'info')
                } else if (result.isDismissed) {
                    const data = {
                        ply_statu: '我要續時',
                    };

                    TutorialDataService.update(e.key, data)
                        .then(() => {
                            this.message = "更新資料，上傳成功!";
                        })
                        .catch((e) => {
                            console.log(e);
                        });

                    Swal.fire({
                        position: 'top-end',
                        icon: 'warning',
                        title: '未完成繳費!',
                        text: '請 在進行 確認一下喲～',
                        showConfirmButton: false,
                        timer: 1200
                    })

                }
            })
        },
        bch_chg_CHKin(a,b,e)
        {
            // Swal.fire(
            //             '清除完畢!',
            //             '目前.',
            //             'success'
            //         )

            for(let ii=0 ; ii < this.tutorials.length ; ii++)
            {
                let x = a +';'+b
                // alert(this.tutorials[ii].memo +'vs'+x);
                if( this.tutorials[ii].memo == x)
                {
                    this.chg_CHKin(this.tutorials[ii] );
                }
            }

            // 
            this.dlt_preBking(e,'已安排上線')
             
        },
        chg_CHKin(e){ 
            var strAry = e.memo .split(';');
            var strAry2 = strAry[1].split(':');
            
            
            e.left_time = parseInt(strAry2[0]) + 1 +":"+ strAry2[1];
 
            e.tmp_idx = strAry[0];

            e.memo="";
            // 進行 修改 
            this.upld_ByCHKin(e);  
        },


        pre_CHKin()
        {
            Swal.fire({
                    title: 'Select field validation',
                    input: 'select',
                    inputOptions: {
                        apples: 'Apples',
                        bananas: 'Bananas',
                        grapes: 'Grapes',
                        oranges: 'Oranges'
                    },
                    inputPlaceholder: 'Select a fruit',
                    showCancelButton: true,
                                    })
        },
        pre_seatSTing(pre_tmp_idx,pre_left_time) {
             this.bch_memo = pre_tmp_idx+';'+pre_left_time

        },



        MdfLfTime_05(e) {

            // var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(30, 'hh:mm');

            // const data = { 
            //      left_time:a.add(b).minutes(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        MdfLfTime_10(e) {
            //  var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(1, 'hh');

            // const data = { 
            //      left_time:a.add(b).hours(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        pmt_onDataChange(items) {

            let _tansCATM = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tansCATM.push({

                    key: key,

                    name: data.name,
                    phone: data.phone,
                    /// 這邊需要再往下製作 ... 累了先睡，再安排吧

                });
            });

            this.pmtLists = _tansCATM;
        },

        BkingNoteonDataChange(items) {

            let _tutorials = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tutorials.push({
                    key: key,
                    
                    // pos: data.pos,
                    // sno: data.sno,
                    // sno_idx: data.sno_idx,
                    // sno_id: data.sno_id,

                    pre_tmp_idx: data.pre_tmp_idx,
                    pre_mb_phone: data.pre_mb_phone, 
                    pre_left_time: data.pre_left_time,

                    ply_amt: data.ply_amt, 
                    ply_statu: data.ply_statu,
                    pre_Seat: data.pre_Seat,
                    stCNT:[],
                    sted:0,

                    // memo_1: data.memo_1,
                    // memo_2: data.memo_2,
                });
            });
            
            this.BkLists = _tutorials;


            // 

            // this.cfg();
        },

        onDataChange(items) {

            let _tutorials = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tutorials.push({
                    key: key,
                    pos: data.pos,
                    sno: data.sno,
                    sno_idx: data.sno_idx,
                    sno_id: data.sno_id,

                    tmp_idx: data.tmp_idx,
                    left_time: data.left_time,
                    memo: data.memo,
                    ply_statu: data.ply_statu,
                });
            });

            this.tutorials = _tutorials;

            // this.cfg();
        },

        // cfg(e){

        //     if( e.pos == '北' && e.left_time !='' )
        //     {
        //         this.exists_Now[1]= parseInt(this.exists_Now[0])+1 ;
        //     }
        //     else if( e.pos == '南' && e.left_time !='' )
        //     {
        //         this.exists_Now[1]= parseInt(this.exists_Now[1])+1 ;
        //     }
        // },


        refreshList() {
            this.currentTutorial = null;
            this.currentIndex = -1;
        },
        cfg() {
            if (this.copyRight_N_auto == false) {
                this.copyRight_T = false;
                this.copyRight_N = false;
                this.copyRight_M = false;

                this.bch_left_time = "";
                this.bch_tmp_idx = "";
                this.auto_tmp_idx = "";
            }

        },

        setActiveTutorial(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index; 

            if (this.copyRight_N_auto != false) {

                //
                this.copyRight_T = true;
                // this.bch_left_time=this.currentTutorial.left_time ;
                this.currentTutorial.left_time = this.bch_left_time;
                this.currentTutorial.ply_statu = '首次';
                //
                this.currentTutorial.tmp_idx = this.auto_tmp_idx;
                this.start_copy++;
                if (this.start_copy % 2 == 0) {
                    this.auto_tmp_idx = parseInt(this.auto_tmp_idx) + 1;
                }  
                this.bch_updta();
                // this.message = "複製更新 成功!";
            }


            if (this.copyRight_N != false) {
                this.currentTutorial.tmp_idx = this.bch_tmp_idx;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }

            if (this.copyRight_T != false) {
                this.currentTutorial.left_time = this.bch_left_time;
                this.bch_updta();
                // this.message = "複製更新 成功!";
            }
            if (this.copyRight_M != false && this.shouldPut== true) {
                this.upldplayGp(tutorial);
                this.BkLists[this.LstX].pre_Seat.push(tutorial); 
            }
  
            
            

            // if (this.copyRight_M != false && this.shouldPut == true) {
            //     this.BkLists[this.LstX].pre_Seat.push(tutorial); 
                
            //     // this.upldplayGp(tutorial);

            //     // - - - - - -  
            //     this.shouldPut = false; 
            // }

            // if (this.shouldPut == false) { 
            //     this.shouldPut = true; 
            // }

        },

        bch_updta() {
            const data = {
                tmp_idx: this.currentTutorial.tmp_idx,
                left_time: this.currentTutorial.left_time,
                ply_statu: this.currentTutorial.ply_statu,
                // memo: this.currentTutorial.memo,
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        } 
        ,


        reSet_pos_0() {
            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 0; index <= 100; index++) {
                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);
                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })
        },

        reSet_pos_1() {
            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 0; index <= 30; index++) {
                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);
                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })

        },

        reSet_pos_2() {

            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 31; index <= 100; index++) {

                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);

                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })

        },

        reSetOne(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index;

            this.currentTutorial.tmp_idx = "";
            this.currentTutorial.left_time = "";
            this.currentTutorial.memo = "";
            this.currentTutorial.ply_statu = "";
            this.currentTutorial.ply_type = "";
            // this.currentTutorial.pmt_List = "";

            const data = {
                tmp_idx: "",
                left_time: "",
                memo: "",

                ply_type: "",
                ply_statu: "",
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        removeAllTutorials() {
            SeatDataService.deleteAll()
                .then(() => {
                    this.refreshList();
                })
                .catch((e) => {
                    console.log(e);
                });
        },
 
        ChkTime2getColor(left_time) {

            let now_H = parseInt(this.dayjs(this.cT).format("HH"))
            let now_M = parseInt(this.dayjs(this.cT).format("mm"))
            let colAry = ['#545454', '#E91E63', '#2196F3']

            var strAry = left_time.split(':')

            let booking_H = parseInt(strAry[0])
            let booking_M = parseInt(strAry[1])

            try {
                if (left_time == "") { return colAry[0] } else if (now_H > booking_H) {
                    if (now_M >= booking_M) { return colAry[1] } else if (now_M < booking_M && now_H >= booking_H) { return colAry[1] }
                } else if (now_H == booking_H) {
                    if (now_M >= booking_M) { return colAry[1] } else if (now_M < booking_M) { return colAry[2] }
                } else if (now_H < booking_H) {
                    if (now_M >= booking_M) { return colAry[2] } else if (now_M < booking_M) { return colAry[2] }
                } else { return colAry[3] }
            } catch { return colAry[3] }
        },
        updateCurrentTime() { this.cT = Date.now(); },

        getFile_name() {
            let L = '靶位收益紀錄_';
            let k = this.dayjs(Date.now()).format("MM月DD日_HH點mm分");
            let J = '.csv';
            this.fileName = L + k + J;
        },


    },
    mounted() {
        // console.log(_tutorials.title);  
        BkingNoteDataService.getAll().on("value", this.BkingNoteonDataChange);
        SeatDataService.getAll().on("value", this.onDataChange);
        // PmtDataService.getAll().on("value", this.pmt_onDataChange);
        this.interval = setInterval(this.updateCurrentTime, 1000);
    },
    beforeDestroy() {
        SeatDataService.getAll().off("value", this.onDataChange);
    },


};
</script>
 

<style>
.list {
    text-align: left;
    max-width: 750px;
    margin: auto;
    /* color: #545454; */
}
</style>
