<template >
  <div class = "h-sreen">
<section>
    <pixi-renderer
      @tick="update"
      :backgroundColor="0x0078FF"
      :height="480"
      :width="640"
    >
      <pixi-container
        :x="320" :y="240"
        :rotation="-t / 40"
      >
        <pixi-sprite v-for="(sprite, key) in sprites" :key="key"
          src="../assets/logo.png"
          :x="sprite.x" :y="sprite.y"
          :scaleX="sprite.scale" :scaleY="sprite.scale"
          :anchorX="0.5" :anchorY="0.5"
          :rotation="sprite.angle + t / 60" />
      </pixi-container>
    </pixi-renderer>
  </section>
  </div>
</template>
 
<script>
export default {
  data () {
    return { t: 0, sprites: [] }
  },
  methods: {
    addSprite () {
      this.sprites.push({
        x: 640 * (0.5 - Math.random()),
        y: 480 * (0.5 - Math.random()),
        angle: 2 * Math.PI * Math.random(),
        scale: 0.25 + 0.5 * Math.random(),
      })
    },
    update (dt) { this.t += dt }
  },
  created () {
    this.addSprite()
    this.addSprite()
    this.addSprite()
  }
}
</script> 
