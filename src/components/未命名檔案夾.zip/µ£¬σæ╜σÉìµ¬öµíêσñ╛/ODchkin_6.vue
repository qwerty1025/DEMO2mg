<template>
    <div class=" flex justify-center  ">
    
        <div class="w-1/12 ml-5">
            
        </div> 
    
        <div class="w-11/12"  >
            <!-- <v-virtual-scroll > -->
            <v-card
                v-scroll.self="onScroll"
                class="overflow-y-auto"
                max-height="720"
            > 
            <v-tabs v-model="tab" active-class="bg-gray-900 text-white" fixed-tabs>

                <v-tab key='k2' href='#k2'>
                    中央 _南場
                </v-tab>

                <v-tab key='k1' href='#k1' v-if="!hide">
                    中央 _北場
                </v-tab> 
    
                <v-tab key='k3' href='#k3' v-if="!hide">
                    北北東 _場
                </v-tab>
            </v-tabs>
            <v-tabs-items v-model="tab">
            
                <v-tab-item key='k1' value='k1'>   
                        <div>  
                            <div class="grid grid-rows-3 grid-flow-col gap-1">
                                <div class="row-span-3 bg-blue-300">01</div>
                                <div class="col-span-2 bg-blue-200">02</div>
                                <div class="row-span-2 col-span-2 bg-blue-100">03</div>
                            </div>  
                        </div> 
                </v-tab-item>
    
                <v-tab-item key='k2' value='k2'> 
                    <div> 
                        <div class="grid grid-cols-6 gap-1">
                        <div class="flex-row mt-2 ">
                            <v-text-field  class="mx-3" 
                                label="登記日期"  
                                outlined dense>
                            </v-text-field>

                            <v-textarea  class="mx-3 " 
                                label="姓名"  
                                outlined dense>
                            </v-textarea>

                            <v-text-field  class="mx-3" 
                                label="靶位"  
                                outlined dense>
                            </v-text-field>  
                        </div>
                        <div class=" col-span-2 flex-row mt-2 bg-gray-100">
                            <div class="w-full flex">
                                <v-text-field  class="mx-3" 
                                    label="登記時間"  
                                    outlined dense>
                                </v-text-field>
                                ~
                                <v-text-field  class="mx-3" 
                                    label="登記時間"  
                                    outlined dense>
                                </v-text-field>
                            </div>

                            <div class="w-full flex ">
                                <v-div  class="w-2/5" >
                                <v-text-field  class="mx-3" 
                                    label="平日 輕體驗"  
                                    outlined dense>
                                </v-text-field>

                                <v-text-field  class="mx-3" 
                                    label="假日 輕體驗"  
                                    outlined dense>
                                </v-text-field> 
 
                            </v-div>
                            
                            <v-div  class="w-3/5" >
                                <v-text-field  class="mx-3" 
                                    label="傳統"  
                                    outlined dense>
                                </v-text-field>

                                <v-text-field  class="mx-3" 
                                    label="反曲"  
                                    outlined dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="複合(A)"  
                                    outlined dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="複合(B)"  
                                    outlined dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="租箭"  
                                    outlined dense>
                                </v-text-field> 
 
                            </v-div>
                                 
                            </div>   
                        </div>
                        <div class="col-span-1 flex-row mt-2 ">
                            <div class="w-full flex mb-2">
                                <v-chip-group  column  class="" >
                                    <v-chip filter dense outlined value="首次" >  學員 </v-chip>
                                    <v-chip filter dense outlined value="免講習" >  票券  </v-chip> 
                                    <v-chip filter dense outlined value="首次" >  KKDay </v-chip>
                                    <v-chip filter dense outlined value="免講習" >  Rezio  </v-chip> 
                                    <v-chip filter dense outlined value="首次" > 多元 </v-chip>
                                    <v-chip filter dense outlined value="免講習" >  其他  </v-chip> 
                                </v-chip-group>
                            </div>

                            <div class="w-full flex">
                                <v-div  class="" >
                                <v-text-field  class="mx-3" 
                                    label="首次.場地費"  
                                    outlined dense>
                                </v-text-field>

                                <v-text-field  class="mx-3" 
                                    label="續時 0.5小時"  
                                    outlined dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="續時 1.0小時"  
                                    outlined dense>
                                </v-text-field> 

                                <v-textarea  class="mx-3 " 
                                    label="其他部分"  
                                    outlined dense>
                                </v-textarea>  
 
                            </v-div>
                            
                            <!-- <v-div  class="w-1/5" > 
                                
                            </v-div> -->
                                 
                            </div>   
                        </div> 
                         <div class="col-span-2 flex-row mt-2 bg-gray-100">
                            <div class="w-full ">
                                <v-text-field  class="mx-1" 
                                    label="經手人"  
                                    outlined dense>
                                </v-text-field>
                            </div>

                            <div class="w-full grid grid-cols-2 gap-0">
                                <v-text-field  class="mx-3 " 
                                    label="現金"  
                                    solo dense>
                                </v-text-field>

                                <v-text-field  class="mx-3 " 
                                    label="匯款"  
                                    solo dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3 " 
                                    label="刷卡"  
                                    solo  dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="LinePay"  
                                    solo  dense>
                                </v-text-field> 
                                <v-text-field  class="mx-3" 
                                    label="網銀"  
                                    solo  dense>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="票券"  
                                    solo  dense>
                                </v-text-field>
                                 
                                 <span class=" col-span-2 font-black"> 收支明細 </span>


                                <v-text-field  class="mx-3" 
                                    label="首次收費"  
                                     dense disabled >
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="收支狀況"  
                                     dense disabled>
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="續時收費"  
                                     dense disabled >
                                </v-text-field> 

                                <v-text-field  class="mx-3" 
                                    label="應收金額"  
                                     dense disabled >
                                </v-text-field>
                                
                                <v-text-field  class="mx-3" 
                                    label="額外收費"  
                                     dense disabled >
                                </v-text-field> 

                                <v-btn class=" mx-6" >
                                  送出
                                </v-btn>

                                
  
                                 
                            </div>   
                        </div> 
                        <div class="col-span-6 grid grid-cols-6 gap-1">
                            <div class="col-start-2 col-span-ㄅ">
                                <v-text-field  class="mx-3" 
                                    label="體驗小計"  
                                    filled dense>
                                </v-text-field> 
                            </div>

                            <div class="col-span-1">
                                <v-text-field  class="mx-3" 
                                    label="弓具小計"  
                                    filled dense>
                                </v-text-field> 
                            </div>

                            <div class="col-span-1">
                                <v-text-field  class="mx-3" 
                                    label="場地小計"  
                                    filled dense>
                                </v-text-field> 
                            </div>
 
                            <div class="col-span-1">
                                <v-text-field  class="mx-3" 
                                    label="其他小計"  
                                    filled dense>
                                </v-text-field> 
                            </div>

                            <div class="col-span-1">
                                <v-text-field  class="mx-3" 
                                    label="總額"  
                                    filled dense>
                                </v-text-field> 
                            </div>
 


                        </div>

                        <!-- <div class="col-span-2 ...">04</div>
                        <div class="...">05</div>
                        <div class="...">06</div>
                        <div class="col-span-2 ...">07</div> -->
                        </div>
                    </div> 
                </v-tab-item>  

                <v-tab-item key='k3' value='k3'>

                    <v-btn class=" mx-6"   @click="add()">
                                         時間增加
                                            </v-btn>
                                        

{{ cuT }} <hr>
                    {{ tutorials }}
                </v-tab-item>
    
    
            </v-tabs-items>
            </v-card>
        </div>
    
    
    
    </div>
</template>
 

<script>
import TutorialDetails from "./bkadd5_Mdf";
import TutorialDataService from "../services/SeatPrepareService";

import SeatDataService from "../services/SeatPrepareService";
import dayjs from 'dayjs';


import PmtDataService from "../services/PmtService";
import Vue from 'vue' 
import JsonCSV from 'vue-json-csv'
Vue.component('downloadCsv', JsonCSV)

export default {
    name: "tutorials-list",
    components: { TutorialDetails },


    data() {
        return {
            // - - - - - 
            currentTime: Date.now(),
            cT:"",
            cuT:"",
            plySTATU:"",
            amenities:[],
            // - - - - - 
            switch1: true,
            switch2: false,


            ex11: ['red'],
            ex: false,


            dialog: false,
            tab: "",
            ckbx: "",
            copyRight_N: false,
            copyRight_T: false,
            copyRight_M: false,

            // - - - - - - - - - - - - - - - 
            dev_TooL_show: false,
            Dev_Tool_0: false,
            Dev_Tool_1: false,
            Dev_Tool_2: false,
            Dev_Tool_3: false,

            bch_left_time: "",
            bch_tmp_idx: "",
            bch_memo: "",

            show: false,
            tutorials: [],
            currentTutorial: null,
            currentIndex: -1,

            // - - - -  - - - -  - - - -  - - - -
            use_BKingGp:false,

            // ply_statu_List:['首次','免講習','保留席','續.未繳費','續0.5','續1.0'],
            // - - - -  - - - -  - - - -  - - - -  
            PmtLists: [], 

            p:['key','name','phone','ply_amt','plyd'],
           
            labels: { 
                key:'流水編號', 
                phone:'手機', 

                build_date:'日期',  
                ply_amt : '收入金額（＋）',
                mb_id:'會員編號',
                mb_name:'客戶',
                pd_ID:'商品編號',
                pd_name:'產品名稱',

                payCash:'現金',
                payLinPay: 'Linepay', 
                payCTCard: '刷卡機', 
                payNetBank: '網路(線上)', 
                payGovTik: '動滋卷',  

                memo:'備註', 
                bls_CNT:'差額', 
                bls_CNT_reson:'差額原因', 

                aCNT_sC:'小分類', 
                pcs_price:'單價', 
                aCNT_name:'會計科目名稱', 
                aCNT_c_ID:'會計科目代號', 
                aCNT_c_name:'科目名稱',  

                bld_name:'建立者',  
            },
            // fields: [ 'name','ply_amt','key','phone','plyd'],
            fields: [ 'name','phone','ply_amt','key','build_date','payCash','payNetBank','payCTCard','payGovTik','payLinPay','memo','bls_CNT','bls_CNT_reson','aCNT_sC','pcs_price','aCNT_name','aCNT_c_ID','aCNT_c_name'],
            // 修改_簡化版本  
            // 日期','原因','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','備註','差額','差額原因','付款方式','小分類','單價','會計科目名稱','會計科目代號','科目名稱','建立者','修改時間', 
            // 原版本
            // 日期','原因','日期班別','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','運動卷','熊好卷','迪卡儂卷','台灣pay','發票號碼','備註','差額','差額原因','付款方式','小分類','單價','收入登錄','會計科目名稱','會計科目代號','科目名稱','學員報名課程代號','建立者','修改時間','5倍卷'
            // - - - -  - - - -  - - - -  - - - - 
            // - - - -  - - - -  - - - -  - - - - 
            fileName:'UUU',
        };
    },
    methods: {

        left_Mdf(detal,e) {

            if (detal == 1) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "客人需要續時 30分鐘 嗎？",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '新增,續時方案 !',
                    cancelButtonText: '取消!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        var strAry = e.left_time.split(":");
                    if (detal == 1) {
                        if (parseInt(strAry[1]) == 30) {
                            e.left_time = parseInt(strAry[0]) + 1 + ":00" ;
                        } 
                        else if (parseInt(strAry[1]) >= 30) {
                            e.left_time =
                                parseInt(strAry[0]) + 1 + ":" + (parseInt(strAry[1]) - 30);
                        } 
                        else if (parseInt(strAry[1]) < 30) {
                            e.left_time =
                                strAry[0] + ":" + (parseInt(strAry[1]) + 30);
                        }
                    }  

                    const data = {
                        left_time: e.left_time,
                    };

                    TutorialDataService.update(e.key, data)
                        .then(() => {
                            this.message = "更新資料，上傳成功!";
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                        
                        Swal.fire(
                        '修改完畢!',
                        '請記得.確認收費',
                        'success'
                        )
                    }
                    }) 
                
            } else if (detal == 2) {

                Swal.fire({
                    title: 'Are you sure?',
                    text: "客人需要續時 1 小時 嗎？",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '新增,續時方案 !',
                    cancelButtonText: '取消!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        var strAry = e.left_time.split(":");
                    if (detal == 2) {
                        e.left_time =
                            parseInt(strAry[0]) + 1 + ":" + strAry[1];
                    }

                    const data = {
                        left_time: e.left_time,
                    };

                    TutorialDataService.update(e.key, data)
                        .then(() => {
                            this.message = "更新資料，上傳成功!";
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                        
                        Swal.fire(
                        '修改完畢!',
                        '請記得.確認收費',
                        'success'
                        )
                    }
                    }) 
                 
            }

            



            
        },

        updateTutorial(e) {
            const data = {
                // sno_id: this.currentTutorial.sno_idx,
                // pos: this.currentTutorial.pos,
                // sno: this.currentTutorial.sno,
                // sno_idx: this.currentTutorial.sno_idx,

                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                memo: e.memo,

                // amt: this.currentTutorial.amt,
                // paymt: this.currentTutorial.paymt,
                ply_statu: e.ply_statu,

                // ply_type: this.currentTutorial.ply_type,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },
        upldtmp_idx(e) {
            const data = {
                 tmp_idx: e.tmp_idx,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        upldleft_time(e) {
            const data = { 
                left_time: e.left_time,  
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        upldplayGp(e) {
            const data = {
                 memo: e.memo,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },
        upldStatu(e) {
            const data = {
                 ply_statu: e.ply_statu,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        upld_Claer(e) {
            const data = {
                 memo: "",
                 left_time:"",
                 tmp_idx: "",
                 ply_statu:"",
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        MdfLfTime_05(e) {

            // var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(30, 'hh:mm');
  
            // const data = { 
            //      left_time:a.add(b).minutes(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        MdfLfTime_10(e) {
            //  var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(1, 'hh');
  
            // const data = { 
            //      left_time:a.add(b).hours(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        pmt_onDataChange(items) {

            let _tansCATM = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tansCATM.push({

                    key: key,
 
                    name: data.name, 
                    phone: data.phone, 
/// 這邊需要再往下製作 ... 累了先睡，再安排吧

                });
            });

            this.pmtLists = _tansCATM;
        },



        onDataChange(items) {

            let _tutorials = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tutorials.push({
                    key: key, 
                    pos: data.pos,
                    sno: data.sno,
                    sno_idx: data.sno_idx,
                    sno_id: data.sno_id,

                    tmp_idx: data.tmp_idx,
                    left_time: data.left_time,
                    memo: data.memo, 
                    ply_statu: data.ply_statu,

                    // player_group: data.player_group,
                    // amt: data.amt,
                    // paymt: data.paymt,

                    // - - - - - - - - - - - - - -

                    // ply_type : data.ply_type,
                    


                    // pmt_sno: data.pmt_sno, 
                });
            });

            this.tutorials = _tutorials;
        },



        refreshList() {
            this.currentTutorial = null;
            this.currentIndex = -1;
        },

        setActiveTutorial(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index;

            if (this.copyRight_N != false) {
                this.currentTutorial.tmp_idx = this.bch_tmp_idx;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }

            if (this.copyRight_T != false) {
                this.currentTutorial.left_time = this.bch_left_time;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }

            if (this.copyRight_M != false) {
                this.currentTutorial.memo = this.bch_memo;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }
        },

        bch_updta() {
            const data = {
                tmp_idx: this.currentTutorial.tmp_idx,
                left_time: this.currentTutorial.left_time,
                memo: this.currentTutorial.memo,
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        }



        // reSet_bch_N(){ if(this.copyRight_N == false) { this.bch_left_time = ""; }  },
        // reSet_bch_T(){ if(this.copyRight_T == false) { this.bch_tmp_idx = ""  ; }  },

        ,


        reSet_pos_0() {
            Swal.fire({
                    title: 'Are you sure?',
                    text: "準備清理資料!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '馬上, 進行清理 !',
                    cancelButtonText: '取消!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        for (let index = 0; index <= 100; index++) { 
                            this.setActiveTutorial(this.tutorials[index], index);
                            this.reSetOne(this.tutorials[index], index); 
                        }
                        
                        Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                        )
                    }
                    }) 
        },
        
        reSet_pos_1() { 
            Swal.fire({
                    title: 'Are you sure?',
                    text: "準備清理資料!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '馬上, 進行清理 !',
                    cancelButtonText: '取消!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        for (let index = 0; index <= 30; index++) { 
                            this.setActiveTutorial(this.tutorials[index], index);
                            this.reSetOne(this.tutorials[index], index); 
                        }
                        
                        Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                        )
                    }
                    })

        },

        reSet_pos_2() {

            Swal.fire({
                    title: 'Are you sure?',
                    text: "準備清理資料!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '馬上, 進行清理 !',
                    cancelButtonText: '取消!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        for (let index = 31; index <= 100; index++) {

                            this.setActiveTutorial(this.tutorials[index], index);
                            this.reSetOne(this.tutorials[index], index);

                        }
                        
                        Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                        )
                    }
                    })

        }, 
          
        reSetOne(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index;

            this.currentTutorial.tmp_idx = "";
            this.currentTutorial.left_time = "";
            this.currentTutorial.memo = "";
            this.currentTutorial.ply_statu = "";
            this.currentTutorial.ply_type = "";
            // this.currentTutorial.pmt_List = "";

            const data = {
                tmp_idx: "",
                left_time: "",
                memo: "",

                ply_type: "",
                ply_statu: "", 
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        removeAllTutorials() {
            SeatDataService.deleteAll()
                .then(() => {
                    this.refreshList();
                })
                .catch((e) => {
                    console.log(e);
                });
        },


        ChkTime2getColor(left_time) { 

            let now_H = parseInt(this.dayjs(this.cT).format("HH"))  
            let now_M = parseInt(this.dayjs(this.cT).format("mm"))  
            let colAry = ['#d3dce6','#E91E63','#2196F3']

            var strAry = left_time.split(':')

            let booking_H = parseInt(strAry[0] )
            let booking_M = parseInt(strAry[1] ) 

            try{  
                if ( left_time == "") { return colAry[0]  }
                else if ( now_H > booking_H )  
                { 
                    if ( now_M >= booking_M ) { return colAry[1]  }
                    else if( now_M < booking_M && now_H >= booking_H ) { return colAry[1] } 
                }
                else if( now_H == booking_H  )
                { 
                    if ( now_M >= booking_M ) { return colAry[1]  }
                    else if( now_M < booking_M ) { return colAry[2]  } 
                }
                else if( now_H < booking_H  )
                { 
                    if ( now_M >= booking_M ) { return colAry[2]  }
                    else if( now_M < booking_M ) { return colAry[2] } 
                } 
                else{ return colAry[3] }
                }
            catch
            { return colAry[3]  } 
      },
      updateCurrentTime(){ this.cT = Date.now(); },
      
      getFile_name()
        {  
          let L ='靶位收益紀錄_'; 
          let k = this.dayjs(Date.now()).format("MM月DD日_HH點mm分");
          let J ='.csv';
          this.fileName = L+k+J ;
        },


    },
    mounted() {
        // console.log(_tutorials.title);  
        SeatDataService.getAll().on("value", this.onDataChange);
        // PmtDataService.getAll().on("value", this.pmt_onDataChange);
        this.interval = setInterval(this.updateCurrentTime, 1000);
    },
    beforeDestroy() {
        SeatDataService.getAll().off("value", this.onDataChange);
    },


};
</script>
 

<style>
.list {
    text-align: left;
    max-width: 750px;
    margin: auto;
}
</style>
