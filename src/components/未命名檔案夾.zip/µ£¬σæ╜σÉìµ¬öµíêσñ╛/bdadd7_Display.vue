<template>
  <div class=" flex justify-center  ">
    
    
    <div class="w-full ">   
        <v-tabs
            v-model="tab"
            background-color="deep-purple" 
            grow
            active-class="bg-gray-900 text-white"
            class="text-gray-500"
          > 
            <v-tab key='k1' href='#k1' v-if="!hide" class="bg-gray-200  "  >    
              中央 _北場
            </v-tab>

            <v-tab key='k2' href='#k2' class="bg-gray-200  " > 
              中央 _南場
            </v-tab>

            <v-tab key='k3' href='#k3' v-if="!hide" class="bg-gray-200  " >    
              北北東 _場  
            </v-tab> 
            
          </v-tabs>  

      <v-tabs-items v-model="tab">
 

        <v-tab-item key='k1' value='k1'> 
          <v-list-item-group 
            color="primary" >
            <v-list-item
              v-for="(tutorial, index) in tutorials"  
              :key="index"
              v-if="tutorial.pos =='北'"
            > 
              <v-list-item-content 
                      class=" text-xs py-2 pl-3 my-1 border-2 rounded-sm  "
                      :class="{ [`bg-${color[parseInt(tutorial.sno)]}-100 border-${color[parseInt(tutorial.sno)]}-300`]: 1 }" 
              >
                <div class=" flex  w-full">
                    <div class=" flex-auto mx-1"> 
                      {{ tutorial.sno }}_{{ tutorial.sno_idx }}  
                    </div>
                    <div class="  flex-auto    text-xs font-black"> 
                      <span class=" p-1 bg-red-500 rounded-full text-white text-xs font-black"> {{ tutorial.tmp_idx.split('---')[0] }} </span>  
                        , <v-chip 
                          :color="ChkTime2getColor_mdf(tutorial.left_time,tutorial.tmp_idx)" dark x-small >
                          {{ tutorial.tmp_idx.split('---')[1] }}離 
                        </v-chip> 
                     
                    <span class=" flex-auto text-xs text-blue-500 ">  
                      {{ tutorial.ply_statu }}   
                    </span> 
                        <v-btn class="mx-1" v-show="tutorial.tmp_idx != '' && tutorial.ply_statu != '續 0.5' && tutorial.ply_statu != '我要續時'" x-small @click="upldStatu(tutorial,'0.5')" > 續0.5</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.tmp_idx != '' && tutorial.ply_statu != '續 1.0' && tutorial.ply_statu != '我要續時'" x-small @click="upldStatu(tutorial,'1.0')" > 續1.0</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.ply_statu == '續 0.5' | tutorial.ply_statu == '續 1.0' |tutorial.ply_statu == '我要續時' " small @click="upldStatu_Mdf(tutorial,'問過不續')" > 不續</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.ply_statu == '續 0.5' | tutorial.ply_statu == '續 1.0' |tutorial.ply_statu == '我要續時' " small @click="upldStatu_Mdf(tutorial,'首時')" > 取消</v-btn> 
                  
                    </div> 
                    <!-- <div class="flex-auto justify-items-end"> 
                      <div class="flex">
                           </div>
                    </div>  -->
                  </div>
              </v-list-item-content>
 
              
              
            </v-list-item>
          </v-list-item-group>
        </v-tab-item>

                <v-tab-item key='k2' value='k2' > 
                  
          <v-list-item-group 
            color="primary" 
            >
            <v-list-item
              v-for="(tutorial, index) in tutorials"  
              :key="index" 
              v-if="tutorial.pos =='南'"
            > 
                 
                  <v-list-item-content 
                      class=" text-xs py-2 pl-3 my-1 border-2 rounded-sm  "
                      :class="{ [`bg-${color[parseInt(tutorial.sno)]}-100 border-${color[parseInt(tutorial.sno)]}-300`]: 1 }" 
              >
                <div class=" flex  w-full">
                    <div class=" flex-auto mx-1"> 
                      {{ tutorial.sno }}_{{ tutorial.sno_idx }}  
                    </div>
                    <div class="  flex-auto    text-xs font-black"> 
                      <span class=" p-1 bg-red-500 rounded-full text-white text-xs font-black"> {{ tutorial.tmp_idx.split('---')[0] }} </span>  
                        , <v-chip 
                          :color="ChkTime2getColor_mdf(tutorial.left_time,tutorial.tmp_idx)" dark x-small >
                          {{ tutorial.tmp_idx.split('---')[1] }}離 
                        </v-chip> 
                     
                    <span class=" flex-auto text-xs text-blue-500 ">  
                      {{ tutorial.ply_statu }}   
                    </span> 
                        <v-btn class="mx-1" v-show="tutorial.tmp_idx != '' && tutorial.ply_statu != '續 0.5' && tutorial.ply_statu != '我要續時'" x-small @click="upldStatu(tutorial,'0.5')" > 續0.5</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.tmp_idx != '' && tutorial.ply_statu != '續 1.0' && tutorial.ply_statu != '我要續時'" x-small @click="upldStatu(tutorial,'1.0')" > 續1.0</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.ply_statu == '續 0.5' | tutorial.ply_statu == '續 1.0' |tutorial.ply_statu == '我要續時' " small @click="upldStatu_Mdf(tutorial,'問過不續')" > 不續</v-btn> 
                        <v-btn class="mx-1" v-show="tutorial.ply_statu == '續 0.5' | tutorial.ply_statu == '續 1.0' |tutorial.ply_statu == '我要續時' " small @click="upldStatu_Mdf(tutorial,'首時')" > 取消</v-btn> 
                  
                    </div> 
                    <!-- <div class="flex-auto justify-items-end"> 
                      <div class="flex">
                           </div>
                    </div>  -->
                  </div>
              </v-list-item-content>
 
            </v-list-item>
          </v-list-item-group>
        </v-tab-item>


      </v-tabs-items>
    </div> 
    
  </div>
</template>
 

<script>

import TutorialDetails from "./bkadd4_Mdf";
 
import SeatDataService from "../services/SeatPrepareService";

export default {
  name: "tutorials-list",
  components: { TutorialDetails },
  

  data() {
    return { 
      tab:"",
      // - - - - 
      color: ['red','red', 'red', 'yellow', 'yellow', 'green', 'green', 'gray', 'gray', 'blue', 'blue', 'red', 'red', 'blue', 'blue',
                'green', 'green', 'red', 'red', 'green', 'green', 'red', 'red', 'yellow', 'yellow', 'blue', 'blue', 'green', 'green',
                'red', 'red', 'yellow', 'yellow', 'green', 'green', 'red', 'red', 'yellow', 'yellow'
            ],
show: false,
      tutorials: [],
      currentTutorial: null,
      currentIndex: -1
    };
  }, 
  methods: { 

    upldStatu(e,type) {
       

      if( type == '0.5' )
      { 
      const  data = {
                 ply_statu: '續 0.5',
            };

            SeatDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
      }
      else if(type == '1.0')
      {
      const  data = {
                 ply_statu: '續 1.0',
            };

            SeatDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });

      }
            

            
        },

        upldStatu_Mdf(e,x){
            const data = {
                 ply_statu: x,
            };

            SeatDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

sh(){

alert('gooo');
},

    onDataChange(items) {
       
      let _tutorials = [];  

      items.forEach((item) => {
        let key = item.key;
        let data = item.val();
        _tutorials.push({
          key: key, 
            pos: data.pos,
            sno: data.sno,
            sno_idx: data.sno_idx,
            tmp_idx: data.tmp_idx,
            left_time: data.left_time,
            memo: data.memo,
            slted: data.slted,
            statu: data.statu,
            ply_statu: data.ply_statu
        });
      });

      this.tutorials = _tutorials; 
    },

    refreshList() {
      this.currentTutorial = null;
      this.currentIndex = -1;
    },

    setActiveTutorial(tutorial, index) {
      this.currentTutorial = tutorial;
      this.currentIndex = index;
    },

    removeAllTutorials() {
      SeatDataService.deleteAll()
        .then(() => {
          this.refreshList();
        })
        .catch((e) => {
          console.log(e);
        });
    },
    // 猜解字串，請輸入正確格式
        ChkTime2getColor_mdf(t, e) {

            let colAry = ['#545454', '#E91E63', '#2196F3', '#57ca85','#C56CD6']

            let now_H = parseInt(this.dayjs(this.cT).format("HH"))
            let now_M = parseInt(this.dayjs(this.cT).format("mm"))

            

            try {
                if (e != '') {

                    var strAry2 = e.split('---')[1]

                    var strAry = strAry2.split(':')

                    // let booking_H = parseInt(strAry[0])
                    let booking_H = parseInt(strAry[0])
                    let booking_M = parseInt(strAry[1])
                    

                    if (now_H > booking_H) {

                        if (now_M >= booking_M) 
                        { return colAry[1] } 
                        else if 
                        (now_M < booking_M && now_H >= booking_H) 
                        { return colAry[1] }
                    } 
                    else if (now_H == booking_H) 
                    {
                        if (now_M >= booking_M) 
                        {   
                            return colAry[1] } 
                        else if (now_M < booking_M) 
                        { return colAry[2] }

                    } else if (now_H < booking_H)
                    {
                         
                        if (now_M >= booking_M) 
                        { return colAry[2] } 
                        else if (now_M < booking_M) 
                        { return colAry[2] }
                         
                        
                    } 
                    else 
                    { 
                        return colAry[0] 
                    }

                // return colAry[1];
            } 
            else if (e == '') { 
                return colAry[3]; // 綠色
            } 
            } 
            catch { return colAry[0] } 
        },
    // - - - - - - - - - - - - - - 

    ChkTime2getColor(left_time) { 

      let now_H = parseInt(this.dayjs(this.cT).format("HH"))  
      let now_M = parseInt(this.dayjs(this.cT).format("mm"))  
      let colAry = ['#d3dce6','#E91E63','#2196F3','#FFFFFF']

      var strAry = left_time.split(':')

      let booking_H = parseInt(strAry[0] )
      let booking_M = parseInt(strAry[1] ) 

      try{  
        if ( left_time == "") { return colAry[0]  }
          else if ( now_H > booking_H )  
          { 
            if ( now_M >= booking_M ) { return colAry[1]  }
            else if( now_M < booking_M && now_H >= booking_H ) { return colAry[1] } 
          }
          else if( now_H == booking_H  )
          { 
            if ( now_M >= booking_M ) { return colAry[1]  }
            else if( now_M < booking_M ) { return colAry[2]  } 
          }
          else if( now_H < booking_H  )
          { 
            if ( now_M >= booking_M ) { return colAry[2]  }
            else if( now_M < booking_M ) { return colAry[2] } 
          } 
          else{ return colAry[3] }
        }
      catch
      { return colAry[3]  } 
          
      },
    
  },
  mounted() {
    // console.log(_tutorials.title);  
     SeatDataService.getAll().on("value", this.onDataChange);  
  },
  beforeDestroy() {
     SeatDataService.getAll().off("value", this.onDataChange);
  }, 

    
};
</script>

<style>
/* .submit-form {
  max-width: 300px;
  margin: auto;
} */
</style>


<style>
.list {
  text-align: left;
  /* max-width: 750px; */
  margin: auto;
}
</style>
