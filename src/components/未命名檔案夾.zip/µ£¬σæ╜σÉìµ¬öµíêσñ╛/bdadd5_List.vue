<template>
    <div class=" flex justify-center  ">
        
        <div class="w-1/4 ml-10">
             


                <div class="flex-c justify-center w-full ">
                     <div class="mx-1"> 
                        <v-overlay
                        :absolute="absolute"
                        :value="overlay"
                        :opacity=1
                        class="h-screen"
                        >
                        <div class="grid grid-cols-5 gap-1">
                            <div class="col-span-4 pl-20">

                                <span class="text-red-500 bg-white px-5 p-3 m-5 rounded-full text-6xl font-black"  v-if="currentTutorial !== null "> {{currentTutorial.pos }}_{{currentTutorial.sno }}_{{currentTutorial.sno_idx }} </span>
                                <span class="text-blue-500 bg-white px-5 p-3 m-5 rounded-full text-6xl font-black"> {{toHere.pos}}_{{toHere.sno}}_{{toHere.sno}}</span>

                            </div>

                            <div class="col-span-1 flex">
                                <v-btn
                                    color="#D32F2F"
                                    @click="overlay = false"
                                    class="m-1"
                                >
                                    取消
                                </v-btn>

                                <v-btn
                                    color="#1976D2" dark 
                                    @click="changPos(toHere.key)"
                                    class="m-1"
                                >
                                    送出
                                </v-btn> 
                            </div> 
                        </div>
                        

                        

                        <div class="grid grid-cols-2 gap-1 mt-5">
                            <div> 
                            <span class="ml-16"> 使用中 </span>
                            <v-chip-group 
                                column
                                v-model="toHere"
                                class="mx-10"
                                >
                                <v-chip
                                    small
                                    active-class="bg-blue-800   text-white text-x"
                                    v-for="(tutorial, index) in tutorials" 
                                    v-if="tutorial.ply_statu != ''"
                                    :key="index"
                                    :value="tutorial"
                                >
                                    {{ tutorial.pos }}_{{ tutorial.sno }}_{{
                                    tutorial.sno_idx
                                    }}
                                </v-chip>
                            </v-chip-group>

                            </div>
                            <div>

                            <span class="ml-16"> 這兒空著呢！ </span>
                            <v-chip-group 
                                column
                                v-model="toHere"
                                class="mx-10"
                                >
                                <v-chip
                                    small
                                    active-class="bg-green-500   text-white text-x"
                                    v-for="(tutorial, index) in tutorials" 
                                    :key="index"
                                    :value="tutorial"
                                >
                                    {{ tutorial.pos }}_{{ tutorial.sno }}_{{
                                    tutorial.sno_idx
                                    }}
                                </v-chip>
                            </v-chip-group>
                            </div>
                        </div>

                        </v-overlay>
                     </div>

                    <div class="mx-1">
                        <v-checkbox v-model="copyRight_T" :label="`點擊後. 啟動複製工具`"></v-checkbox>
                        <v-text-field clearable solo dense v-model="bch_left_time" class="text-xs " label="離場時間" placeholder="離時間">
                        </v-text-field>
                    </div>
    
                    <hr>
                    <div class="mx-1">
                        <v-checkbox v-model="use_BKingGp" :label="`點擊後. 顯示客人群組 ` "></v-checkbox>
                        <v-checkbox v-model="copyRight_M" :label="`點擊後. 啟動複製工具 ` "></v-checkbox>
                        <v-text-field clearable solo dense v-model="bch_memo" class="text-xs  " label="客人備註">
                        </v-text-field>
                    </div>
    
    
                    <div class="mx-1">
                        <v-checkbox text v-model="dialog" @click="removeST" label="開啟.靶位清理工具"></v-checkbox>
                        <v-row>
                            <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_0">全場(01 ~ 20)</v-btn>
                            <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_1">北場(01 ~ 11)</v-btn>
                            <v-btn class="my-1" v-show="dialog" solo @click="reSet_pos_2">南場(12 ~ 18)</v-btn>
                        </v-row>
                    </div>
                    <br>
    
                    <div class="mx-1">  
                        目前上線人數： (預計顯示 功能) 
                        <br> 北場(首次/ 續時): 
                        <br> 南場(首次/ 續時):
                    </div>
    
                </div> 
        </div>
    
        <div class="w-3/4"> 
            <v-card v-scroll.self="onScroll" class="overflow-y-auto" max-height="720"> 
 
                        
                <v-tabs v-model="tab" active-class="bg-gray-900 text-white" fixed-tabs>
                    <v-tab key='k1' href='#k1' v-if="!hide">
                        中央 _北場
                    </v-tab>
    
                    <v-tab key='k2' href='#k2'>
                        中央 _南場
                    </v-tab>
    
                    <v-tab key='k3' href='#k3' v-if="!hide">
                        北北東 _場
                    </v-tab>
                </v-tabs>
                <v-tabs-items v-model="tab">
    
                    <v-tab-item key='k1' value='k1'>
                        <div> 
                            <v-list-item-group color="primary">
                                <v-list-item v-for="(tutorial, index) in tutorials" :key="index" v-if="tutorial.pos =='北'" @click="setActiveTutorial(tutorial, index)">
                                    <v-list-item-content class=" text-xs  py-2 pl-3 my-1 border-2 rounded-sm " :class="{ [`bg-${color[parseInt(tutorial.sno)]}-100 border-${color[parseInt(tutorial.sno)]}-300`]: 1 }" @click="setActiveTutorial(tutorial, index)">
                                        <div class="grid grid-cols-7 gap-1">
                                            <div class="col-span-2 flex Justify-end">

                                                <!-- <v-btn class=" mx-6" v-show="tutorial.tmp_idx !='' && tutorial.left_time !='' " @click="upld_Claer(tutorial)">
                                                    自動登記
                                                </v-btn> -->

                                                <v-btn class=" mx-6" v-show="dialog" @click="upld_Claer(tutorial)">
                                                    清掃靶位
                                                </v-btn>
    
                                                <v-chip class="my-2 m-3" :color="ChkTime2getColor(tutorial.left_time)" 
                                                @click="chgPos(tutorial)" > {{ tutorial.pos }}_{{ tutorial.sno }}_{{ tutorial.sno_idx }}  
                                                </v-chip>

                                                  

                                                <v-text-field v-show="use_BKingGp" class=" mr-3" label="客人備註" v-model=" tutorial.memo " @change="upldplayGp(tutorial)" dense></v-text-field>
                                            </div>
    
                                            <div class="col-span-5 flex"> 
                                                <v-text-field solo class="w-1/5 mx-6" label="牌號" v-model=" tutorial.tmp_idx " @change="upldtmp_idx(tutorial)" dense></v-text-field>
                                                <v-text-field class="w-1/5 mx-3" label="離場時間" v-model=" tutorial.left_time " @change="upldleft_time(tutorial)" dense></v-text-field>
    
                                                <v-chip-group v-model="tutorial.ply_statu" @change="upldStatu(tutorial)" column class="w-3/5">
                                                    <v-chip filter small outlined value="首次"> 首次 </v-chip>
                                                    <v-chip filter small outlined value="免講習"> 免講習 </v-chip>
                                                    <v-chip filter small outlined value="上課"> 上課 </v-chip>
                                                    <v-chip v-show="tutorial.ply_statu == '續.已繳'" filter small outlined value="續.已繳"> 續.已繳費 </v-chip>
                                                </v-chip-group>
                                                <v-btn v-show="tutorial.ply_statu == '我要續時'" filter solo value="我要續時" @click="extendPayChk(tutorial)"> 續時.繳費 </v-btn>
    
                                            </div>
                                        </div>
                                    </v-list-item-content> 
                                </v-list-item>
    
                            </v-list-item-group>
                        </div>
                    </v-tab-item>
    
                    <v-tab-item key='k2' value='k2'>
                        <div>
                            <v-list-item-group color="primary">
                                <v-list-item v-for="(tutorial, index) in tutorials" :key="index" v-if="tutorial.pos =='南'" @click="setActiveTutorial(tutorial, index)">
                                    <v-list-item-content class=" text-xs  py-2 pl-3 my-1 border-2 rounded-sm " :class="{ [`bg-${color[parseInt(tutorial.sno)]}-100 border-${color[parseInt(tutorial.sno)]}-300`]: 1 }" @click="setActiveTutorial(tutorial, index)">
                                        <div class="grid grid-cols-7 gap-1">
                                            <div class="col-span-2 flex Justify-end">
                                                <v-btn class=" mx-6" v-show="dialog" @click="upld_Claer(tutorial)">
                                                    清掃靶位
                                                </v-btn> 
                                                <!-- <v-chip class="my-2 m-3" :color="ChkTime2getColor(tutorial.left_time)"> {{ tutorial.pos }}_{{ tutorial.sno }}_{{ tutorial.sno_idx }} </v-chip> -->
                                                 <v-chip class="my-2 m-3" :color="ChkTime2getColor(tutorial.left_time)" 
                                                @click="chgPos(tutorial)" > {{ tutorial.pos }}_{{ tutorial.sno }}_{{ tutorial.sno_idx }}  
                                                </v-chip>

                                                <v-text-field v-show="use_BKingGp" class=" mr-3" label="客人備註" v-model=" tutorial.memo " @change="upldplayGp(tutorial)" dense></v-text-field>
                                            </div>
    
                                            <div class="col-span-5 flex"> 
                                                <v-text-field solo class="w-1/5 mx-6" label="牌號" v-model=" tutorial.tmp_idx " @change="upldtmp_idx(tutorial)" dense></v-text-field>
                                                <v-text-field class="w-1/5 mx-3" label="離場時間" v-model=" tutorial.left_time " @change="upldleft_time(tutorial)" dense></v-text-field>
    
                                                <v-chip-group v-model="tutorial.ply_statu" @change="upldStatu(tutorial)" column class="w-3/5">
                                                    <v-chip filter small outlined value="首次"> 首次 </v-chip>
                                                    <v-chip filter small outlined value="免講習"> 免講習 </v-chip>
                                                    <v-chip filter small outlined value="上課"> 上課 </v-chip>
                                                    <v-chip v-show="tutorial.ply_statu == '續.已繳'" filter small outlined value="續.已繳"> 續.已繳費 </v-chip>
                                                </v-chip-group>
                                                <v-btn v-show="tutorial.ply_statu == '我要續時'" filter solo value="我要續時" @click="extendPayChk(tutorial)"> 續時.繳費 </v-btn>
    
                                            </div>
                                        </div>
                                    </v-list-item-content> 
                                </v-list-item> 
                            </v-list-item-group>
                        </div>
                    </v-tab-item>
    
                    <v-tab-item key='k3' value='k3'> 
                         <div>
                            <!-- {{ tutorial }} -->
                           
                        </div>
                    </v-tab-item> 
                </v-tabs-items>
            </v-card>
        </div>
    
    
    
    </div>
</template>
 

<script>
import TutorialDetails from "./bkadd5_Mdf";
import TutorialDataService from "../services/SeatPrepareService";

import SeatDataService     from "../services/SeatPrepareService";
import HistoryDataService  from "../services/HistoryDataService";
import dayjs from 'dayjs';


import PmtDataService from "../services/PmtService";
import Vue from 'vue'
import JsonCSV from 'vue-json-csv'
Vue.component('downloadCsv', JsonCSV)

export default {
    name: "tutorials-list",
    components: { TutorialDetails },


    data() {
        return {
            // - - - - - 
            currentTime: Date.now(),
            cT: "",
            cuT: "",
            plySTATU: "",
            amenities: [],
            // - - - - - 
            switch1: true,
            switch2: false,
            color: ['red','red', 'red', 'yellow', 'yellow', 'green', 'green', 'gray', 'gray', 'blue', 'blue', 'red', 'red', 'blue', 'blue',
                'green', 'green', 'red', 'red', 'green', 'green', 'red', 'red', 'yellow', 'yellow', 'blue', 'blue', 'green', 'green',
                'red', 'red', 'yellow', 'yellow', 'green', 'green', 'red', 'red', 'yellow', 'yellow'
            ],


            ex11: ['red'],
            ex: false,


            dialog: false,
            tab: "",
            ckbx: "",
            copyRight_N: false,
            copyRight_T: false,
            copyRight_M: false,

            // - - - - - - - - - - - - - - - 
            dev_TooL_show: false,
            Dev_Tool_0: false,
            Dev_Tool_1: false,
            Dev_Tool_2: false,
            Dev_Tool_3: false,

            bch_left_time: "",
            bch_tmp_idx: "",
            bch_memo: "",

            show: false,
            tutorials: [],
            currentTutorial: null,
            currentIndex: -1,

            // - - - -  - - - -  - - - -  - - - -
            use_BKingGp: false,

            // ply_statu_List:['首次','免講習','保留席','續.未繳費','續0.5','續1.0'],
            // - - - -  - - - -  - - - -  - - - -  
            PmtLists: [],

            p: ['key', 'name', 'phone', 'ply_amt', 'plyd'],

            labels: {
                key: '流水編號',
                phone: '手機',

                build_date: '日期',
                ply_amt: '收入金額（＋）',
                mb_id: '會員編號',
                mb_name: '客戶',
                pd_ID: '商品編號',
                pd_name: '產品名稱',

                payCash: '現金',
                payLinPay: 'Linepay',
                payCTCard: '刷卡機',
                payNetBank: '網路(線上)',
                payGovTik: '動滋卷',

                memo: '備註',
                bls_CNT: '差額',
                bls_CNT_reson: '差額原因',

                aCNT_sC: '小分類',
                pcs_price: '單價',
                aCNT_name: '會計科目名稱',
                aCNT_c_ID: '會計科目代號',
                aCNT_c_name: '科目名稱',

                bld_name: '建立者',
            },
            // fields: [ 'name','ply_amt','key','phone','plyd'],
            fields: ['name', 'phone', 'ply_amt', 'key', 'build_date', 'payCash', 'payNetBank', 'payCTCard', 'payGovTik', 'payLinPay', 'memo', 'bls_CNT', 'bls_CNT_reson', 'aCNT_sC', 'pcs_price', 'aCNT_name', 'aCNT_c_ID', 'aCNT_c_name'],
            // 修改_簡化版本  
            // 日期','原因','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','備註','差額','差額原因','付款方式','小分類','單價','會計科目名稱','會計科目代號','科目名稱','建立者','修改時間', 
            // 原版本
            // 日期','原因','日期班別','收入金額（＋）','會員編號','客戶','商品編號','產品名稱','銷售數量','小計','現金','網路(線上)','刷卡機','匯款','動滋卷','Linepay','運動卷','熊好卷','迪卡儂卷','台灣pay','發票號碼','備註','差額','差額原因','付款方式','小分類','單價','收入登錄','會計科目名稱','會計科目代號','科目名稱','學員報名課程代號','建立者','修改時間','5倍卷'
            // - - - -  - - - -  - - - -  - - - - 
            // - - - -  - - - -  - - - -  - - - - 
            fileName: 'UUU',
            absolute: true,
            overlay: false,
            toHere:"",
            
        };
    },
    methods: {
        chgPos(e){
            this.overlay = !this.overlay

            // alert(e.key);
        },

        changPos(key){  
            const data = {  
                tmp_idx: this.currentTutorial.tmp_idx,
                left_time: this.currentTutorial.left_time,
                memo: this.currentTutorial.memo,
                ply_statu:this.currentTutorial.ply_statu,
            };
            const OLD = { 
                tmp_idx:"",
                left_time:"",
                memo:"",
                ply_statu:"", 
            }; 

            TutorialDataService.update(key, data)
                .then(() => { 
                })
                .catch((e) => {
                    console.log(e);
                });

            TutorialDataService.update(this.currentTutorial.key, OLD)
             .then(() => { 
                    Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: '修改完畢!',
                            text: '靶位已進行 調整',
                            showConfirmButton: false,
                            timer: 1200
                            } 
                        )
                    this.overlay = false;    
                })
                .catch((e) => {
                    console.log(e);
                }); 
            this.upld_History_mdf(this.currentTutorial);      
        },

        removeST() {
            this.bch_memo = "";
            this.bch_left_time = "";
            this.copyRight_M = false;
            this.copyRight_T = false;
        },

        left_Mdf(detal, e) {
            var strAry = e.left_time.split(":");

            if (detal == 1) {

                if (detal == 1) {
                    if (parseInt(strAry[1]) == 30) {
                        e.left_time = parseInt(strAry[0]) + 1 + ":00";
                    } else if (parseInt(strAry[1]) >= 30) {
                        e.left_time =
                            parseInt(strAry[0]) + 1 + ":" + (parseInt(strAry[1]) - 30);
                    } else if (parseInt(strAry[1]) < 30) {
                        e.left_time =
                            strAry[0] + ":" + (parseInt(strAry[1]) + 30);
                    }
                }

                const data = {
                    left_time: e.left_time,
                    ply_statu: '續.已繳',
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });

                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: '修改完畢!',
                    text: '請記得.確認收費',
                    showConfirmButton: false,
                    timer: 1200
                })
                // Swal.fire({
                //     title: 'Are you sure?',
                //     text: "客人需要續時 30分鐘 嗎？",
                //     icon: 'warning',
                //     showCancelButton: true,
                //     confirmButtonColor: '#3085d6',
                //     cancelButtonColor: '#d33',
                //     confirmButtonText: '新增,續時方案 !',
                //     cancelButtonText: '取消!'
                //     }).then((result) => {
                //     if (result.isConfirmed) {
                //         var strAry = e.left_time.split(":");
                //     if (detal == 1) {
                //         if (parseInt(strAry[1]) == 30) {
                //             e.left_time = parseInt(strAry[0]) + 1 + ":00" ;
                //         } 
                //         else if (parseInt(strAry[1]) >= 30) {
                //             e.left_time =
                //                 parseInt(strAry[0]) + 1 + ":" + (parseInt(strAry[1]) - 30);
                //         } 
                //         else if (parseInt(strAry[1]) < 30) {
                //             e.left_time =
                //                 strAry[0] + ":" + (parseInt(strAry[1]) + 30);
                //         }
                //     }  

                //     const data = {
                //         left_time: e.left_time,
                //         ply_statu: '續.已繳',
                //     };

                //     TutorialDataService.update(e.key, data)
                //         .then(() => {
                //             this.message = "更新資料，上傳成功!";
                //         })
                //         .catch((e) => {
                //             console.log(e);
                //         });

                //         Swal.fire(
                //         { 
                //             position: 'top-end',
                //             icon: 'success',
                //             title: '修改完畢!',
                //             text:'請記得.確認收費',
                //             showConfirmButton: false,
                //             timer: 1200
                //         }
                //         )
                //     }
                //     }) 

            } else if (detal == 2) {
                if (detal == 2) {
                    e.left_time =
                        parseInt(strAry[0]) + 1 + ":" + strAry[1];
                }

                const data = {
                    left_time: e.left_time,
                    ply_statu: '續.已繳',
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });

                Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: '修改完畢!',
                        text: '請記得.確認收費',
                        showConfirmButton: false,
                        timer: 1200
                    }

                )


                // Swal.fire({
                //     title: 'Are you sure?',
                //     text: "客人需要續時 1 小時 嗎？",
                //     icon: 'warning',
                //     showCancelButton: true,
                //     confirmButtonColor: '#3085d6',
                //     cancelButtonColor: '#d33',
                //     confirmButtonText: '新增,續時方案 !',
                //     cancelButtonText: '取消!'
                //     }).then((result) => {
                //     if (result.isConfirmed) {
                //         var strAry = e.left_time.split(":");
                //     if (detal == 2) {
                //         e.left_time =
                //             parseInt(strAry[0]) + 1 + ":" + strAry[1];
                //     }

                //     const data = {
                //         left_time: e.left_time,
                //         ply_statu: '續.已繳',
                //     };

                //     TutorialDataService.update(e.key, data)
                //         .then(() => {
                //             this.message = "更新資料，上傳成功!";
                //         })
                //         .catch((e) => {
                //             console.log(e);
                //         });

                //         Swal.fire( 
                //         { 
                //             position: 'top-end',
                //             icon: 'success',
                //             title: '修改完畢!',
                //             text:'請記得.確認收費',
                //             showConfirmButton: false,
                //             timer: 1200
                //         }

                //         )
                //     }
                //     }) 

            }






        },

        updateTutorial(e) {
            const data = {
                // sno_id: this.currentTutorial.sno_idx,
                // pos: this.currentTutorial.pos,
                // sno: this.currentTutorial.sno,
                // sno_idx: this.currentTutorial.sno_idx,

                tmp_idx: e.tmp_idx,
                left_time: e.left_time,
                memo: e.memo,

                // amt: this.currentTutorial.amt,
                // paymt: this.currentTutorial.paymt,
                ply_statu: e.ply_statu,

                // ply_type: this.currentTutorial.ply_type,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },
        upldtmp_idx(e) {
            const data = {
                tmp_idx: e.tmp_idx,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });  
            this.upld_History(e);
        },

        upldleft_time(e) {
            const data = {
                left_time: e.left_time,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
            this.upld_History(e);
        },

        upldplayGp(e) {
            const data = {
                memo: e.memo,
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },
        upldStatu(e) {

            if (e.ply_statu == "" | e.ply_statu == null | e.ply_statu == '') {
                const dat = {
                    ply_statu: "",
                };

                TutorialDataService.update(e.key, dat)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });


            } else {
                const data = {
                    ply_statu: e.ply_statu,
                };

                TutorialDataService.update(e.key, data)
                    .then(() => {
                        this.message = "更新資料，上傳成功!";
                    })
                    .catch((e) => {
                        console.log(e);
                    });

            }
            this.upld_History(e);

        },

        upld_History(e) {


            if( e.tmp_idx !='' && e.left_time != '' && e.ply_statu !='' )
            {
                const data = {
                // 系統.設定資料
                pos: e.pos,
                sno: e.sno,
                sno_idx: e.sno_idx,
                // 主要變動資料
                tmp_idx: e.tmp_idx, 
                left_time: e.left_time, 
                ply_statu:e.ply_statu, 
                memo:e.memo,   
                cratTime:this.dayjs(Date.now()).toISOString(),
            };

            HistoryDataService.create(data)
                .then(() => {
                    

                //      Swal.fire({
                //         position: 'top-end',
                //         icon: 'warning',
                //         title: '資料新增成功',
                //         text: e.left_time+ '請 在進行 確認一下喲～',
                //         showConfirmButton: false,
                        
                // })
                })
                .catch((e) => {
                    console.log(e);
                });

                // Swal.fire({
                //         position: 'top-end',
                //         icon: 'warning',
                //         title: '正在謄寫歷史資料',
                //         text: '請 在進行 確認一下喲～',
                //         showConfirmButton: false,
                //         timer: 1200
                //     }) 
            }

            
            
        },
        upld_History_mdf(e) {


            if( e.tmp_idx !='' && e.left_time != '' && e.ply_statu !='' )
            {
                const data = {
                // 系統.設定資料
                pos: e.pos,
                sno: e.sno,
                sno_idx: e.sno_idx,
                // 主要變動資料
                tmp_idx: e.tmp_idx, 
                left_time: e.left_time, 
                ply_statu:'換靶位', 
                memo:e.memo,   
                cratTime:this.dayjs(Date.now()).toISOString(),
            };

            HistoryDataService.create(data)
                .then(() => {
                    

                //      Swal.fire({
                //         position: 'top-end',
                //         icon: 'warning',
                //         title: '資料新增成功',
                //         text: e.left_time+ '請 在進行 確認一下喲～',
                //         showConfirmButton: false,
                        
                // })
                })
                .catch((e) => {
                    console.log(e);
                }); 
            }

            
            
        },

        upld_Claer(e) {
            const data = {
                memo: "",
                left_time: "",
                tmp_idx: "",
                ply_statu: "",
            };

            TutorialDataService.update(e.key, data)
                .then(() => {
                    this.message = "更新資料，上傳成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },
        extendPayChk(e) {
            Swal.fire({
                title: '續時 繳費確認 ',
                text: "教練已詢問，請櫃檯協助收費",
                icon: 'question',
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: '續  0.5 小時',
                denyButtonText: `續 1 小時`,
                cancelButtonText: '取消 !'
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {

                    this.left_Mdf(1, e)
                    // Swal.fire('Saved!', '', 'success')
                } else if (result.isDenied) {

                    this.left_Mdf(2, e)
                    // Swal.fire('Changes are not saved', '', 'info')
                } else if (result.isDismissed) {
                    const data = {
                        ply_statu: '我要續時',
                    };

                    TutorialDataService.update(e.key, data)
                        .then(() => {
                            this.message = "更新資料，上傳成功!";
                        })
                        .catch((e) => {
                            console.log(e);
                        });

                    Swal.fire({
                        position: 'top-end',
                        icon: 'warning',
                        title: '未完成繳費!',
                        text: '請 在進行 確認一下喲～',
                        showConfirmButton: false,
                        timer: 1200
                    })

                }
            })
        },



        MdfLfTime_05(e) {

            // var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(30, 'hh:mm');

            // const data = { 
            //      left_time:a.add(b).minutes(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        MdfLfTime_10(e) {
            //  var a = dayjs.duration(e.left_time, 'hh:mm');
            // var b = dayjs.duration(1, 'hh');

            // const data = { 
            //      left_time:a.add(b).hours(), 
            // };

            // TutorialDataService.update(e.key, data)
            //     .then(() => {
            //         this.message = "更新資料，上傳成功!";
            //     })
            //     .catch((e) => {
            //         console.log(e);
            //     });
        },

        pmt_onDataChange(items) {

            let _tansCATM = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tansCATM.push({

                    key: key,

                    name: data.name,
                    phone: data.phone,
                    /// 這邊需要再往下製作 ... 累了先睡，再安排吧

                });
            });

            this.pmtLists = _tansCATM;
        },



        onDataChange(items) {

            let _tutorials = [];
            items.forEach((item) => {
                let key = item.key;
                let data = item.val();
                _tutorials.push({
                    key: key,
                    pos: data.pos,
                    sno: data.sno,
                    sno_idx: data.sno_idx,
                    sno_id: data.sno_id,

                    tmp_idx: data.tmp_idx,
                    left_time: data.left_time,
                    memo: data.memo,
                    ply_statu: data.ply_statu,
                });
            });

            this.tutorials = _tutorials;
        },



        refreshList() {
            this.currentTutorial = null;
            this.currentIndex = -1;
        },

        setActiveTutorial(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index;

            if (this.copyRight_N != false) {
                this.currentTutorial.tmp_idx = this.bch_tmp_idx;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }

            if (this.copyRight_T != false) {
                this.currentTutorial.left_time = this.bch_left_time;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }

            if (this.copyRight_M != false) {
                this.currentTutorial.memo = this.bch_memo;
                this.bch_updta();
                this.message = "複製更新 成功!";
            }
        },

        bch_updta() {
            const data = {
                tmp_idx: this.currentTutorial.tmp_idx,
                left_time: this.currentTutorial.left_time,
                memo: this.currentTutorial.memo,
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        }



        // reSet_bch_N(){ if(this.copyRight_N == false) { this.bch_left_time = ""; }  },
        // reSet_bch_T(){ if(this.copyRight_T == false) { this.bch_tmp_idx = ""  ; }  },

        ,


        reSet_pos_0() {
            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 0; index <= 100; index++) {
                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);
                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })
        },

        reSet_pos_1() {
            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 0; index <= 30; index++) {
                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);
                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })

        },

        reSet_pos_2() {

            Swal.fire({
                title: 'Are you sure?',
                text: "準備清理資料!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '馬上, 進行清理 !',
                cancelButtonText: '取消!'
            }).then((result) => {
                if (result.isConfirmed) {
                    for (let index = 31; index <= 100; index++) {

                        this.setActiveTutorial(this.tutorials[index], index);
                        this.reSetOne(this.tutorials[index], index);

                    }

                    Swal.fire(
                        '清除完畢!',
                        '目前.',
                        'success'
                    )
                }
            })

        },

        reSetOne(tutorial, index) {

            this.currentTutorial = tutorial;
            this.currentIndex = index;

            this.currentTutorial.tmp_idx = "";
            this.currentTutorial.left_time = "";
            this.currentTutorial.memo = "";
            this.currentTutorial.ply_statu = "";
            this.currentTutorial.ply_type = "";
            // this.currentTutorial.pmt_List = "";

            const data = {
                tmp_idx: "",
                left_time: "",
                memo: "",

                ply_type: "",
                ply_statu: "",
            };

            SeatDataService.update(this.currentTutorial.key, data)
                .then(() => {
                    this.message = "更新成功!";
                })
                .catch((e) => {
                    console.log(e);
                });
        },

        removeAllTutorials() {
            SeatDataService.deleteAll()
                .then(() => {
                    this.refreshList();
                })
                .catch((e) => {
                    console.log(e);
                });
        },


        ChkTime2getColor(left_time) {

            let now_H = parseInt(this.dayjs(this.cT).format("HH"))
            let now_M = parseInt(this.dayjs(this.cT).format("mm"))
            let colAry = ['#d3dce6', '#E91E63', '#2196F3']

            var strAry = left_time.split(':')

            let booking_H = parseInt(strAry[0])
            let booking_M = parseInt(strAry[1])

            try {
                if (left_time == "") { return colAry[0] } else if (now_H > booking_H) {
                    if (now_M >= booking_M) { return colAry[1] } else if (now_M < booking_M && now_H >= booking_H) { return colAry[1] }
                } else if (now_H == booking_H) {
                    if (now_M >= booking_M) { return colAry[1] } else if (now_M < booking_M) { return colAry[2] }
                } else if (now_H < booking_H) {
                    if (now_M >= booking_M) { return colAry[2] } else if (now_M < booking_M) { return colAry[2] }
                } else { return colAry[3] }
            } catch { return colAry[3] }
        },
        updateCurrentTime() { this.cT = Date.now(); },

        getFile_name() {
            let L = '靶位收益紀錄_';
            let k = this.dayjs(Date.now()).format("MM月DD日_HH點mm分");
            let J = '.csv';
            this.fileName = L + k + J;
        },


    },
    mounted() {
        // console.log(_tutorials.title);  
        SeatDataService.getAll().on("value", this.onDataChange);
        // PmtDataService.getAll().on("value", this.pmt_onDataChange);
        this.interval = setInterval(this.updateCurrentTime, 1000);
    },
    beforeDestroy() {
        SeatDataService.getAll().off("value", this.onDataChange);
    },


};
</script>
 

<style>
.list {
    text-align: left;
    max-width: 750px;
    margin: auto;
}
</style>
